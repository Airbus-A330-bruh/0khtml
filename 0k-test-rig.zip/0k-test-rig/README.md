# 0K file:// test rig

Tests the single-file 0K build in headless Chromium. Only the **bottom** of the network stack (the WebRTC "Pulsar"
tunnel) is replaced by a local server; everything above it (virtual service worker, shim, Scramjet, controller,
libcurl.js) is the real code from the HTML file under test.

## Setup
    cd tests && npm install            # ws, socket.io, three, cesium, wisp-server-node
    pip install playwright && playwright install chromium

## Re-apply the fixes to a new base
    python3 patches/build.py  YOUR_BASE.html  OUT.html
Every edit is an exact-match replacement that must match exactly once. If the new base changed the same code it stops
with `PATCH FAILED [part] ...` instead of silently doing the wrong thing. Bigger code blocks live in `patches/snippets/`.

## Run (paths must be absolute)
    python3 tests/build_test.py OUT.html tests/test.html            # swap tunnel for the local server
    python3 tests/run_features.py $PWD/tests/test.html results.json # ~160 feature checks (workers, modules, ws, audio, cookies, resilience...)
    python3 tests/run_three.py    $PWD/tests/test.html shot.png       # three.js: importmap, GLTF via fetch(Request), WebSocket multiplayer
    python3 tests/run_cesium.py   $PWD/tests/test.html shot.png       # CesiumJS globe (web workers)   [GeoFS is built on Cesium]
    python3 tests/run_flight.py   $PWD/tests/test.html shot.png       # moving camera streaming imagery tiles

    python3 tests/build_test_libcurl.py OUT.html tests/test_libcurl.html    # keeps the REAL libcurl.js, uses a Wisp relay
    NOKEEPALIVE=1 python3 tests/run_libcurl.py $PWD/tests/test_libcurl.html # WebSocket handshake, subprotocol, throughput

Real game builds are not bundled (third-party). To reproduce the Unity/Godot runs, put a build in `tests/sites/<name>.test/`
and run `python3 tests/run_game.py $PWD/tests/test.html https://<name>.test/index.html shot.png 90`
(Unity: github.com/usama1095/unity-webgl-3d-platformer-game, Brotli; Godot 4: github.com/jenemia/BuildingSlash, single-thread).
Set `GZIPALL=1` to serve like GitHub Pages; `.br`/`.gz` files get a Content-Encoding automatically.
`tests/probe.py <html> <url> "<js>"` runs a snippet inside a proxied page (`w` = the proxied window).
