"""Exact-match patching of the single-file 0K build. Every edit asserts it matched exactly once,
so a patch can never silently fail or hit the wrong place."""
import re

class Doc:
    def __init__(self, path):
        self.s = open(path, encoding='utf8').read()
        self.log = []

    def _span(self, part):
        """(start, end) of the *body* of a <script> block, selected by id, or by 'module' / 'boot0' / 'boot1'."""
        s = self.s
        if part in ('module',):
            i = s.index('<script type="module">')
        elif part in ('boot0', 'boot1', 'boot2'):
            # anonymous plain <script> blocks, in document order
            idx = [m.start() for m in re.finditer(r'<script>', s)]
            i = idx[int(part[-1])]
        else:
            i = s.index(f'id="{part}"')
            i = s.rindex('<script', 0, i)
        j = s.index('>', i) + 1
        k = s.index('</script>', j)
        return j, k

    def edit(self, part, old, new, why=''):
        j, k = self._span(part)
        body = self.s[j:k]
        n = body.count(old)
        if n != 1:
            raise SystemExit(f'PATCH FAILED [{part}] matched {n}x ({why}): {old[:90]!r}')
        body = body.replace(old, new)
        self.s = self.s[:j] + body + self.s[k:]
        self.log.append((part, why))

    def get(self, part):
        j, k = self._span(part)
        return self.s[j:k]

    def save(self, path):
        open(path, 'w', encoding='utf8').write(self.s)
