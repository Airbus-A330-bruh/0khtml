  /* ============================================================ AudioWorklet === */
  // Worklet.addModule() fetches the script natively, so it cannot load our prefix-form file:// urls (Godot's audio worklets,
  // Tone.js / Web Audio libraries...). Fetch the module through the proxy and hand the worklet a blob instead. The code is
  // deliberately NOT run through Scramjet's rewriter: a worklet global scope has no DOM and none of Scramjet's helpers.
  {
    const NW = window.Worklet && Worklet.prototype.addModule;
    if (NW) {
      const wf = window.fetch;
      const makeBlobUrl = URL.createObjectURL.bind(URL);
      Worklet.prototype.addModule = function addModule(url, opts) {
        const self = this;
        return (async () => {
          let pfx = String(url);
          if (!isPfx(pfx)) {
            if (/^(blob:|data:)/.test(pfx)) return NW.call(self, pfx, opts);
            try { pfx = vsw.toPfx(new URL(pfx, cur()).href); } catch { return NW.call(self, url, opts); }
          }
          const res = await wf.call(window, pfx);
          if (!res.ok) throw new DOMException('Unable to load a worklet\'s module (HTTP ' + res.status + ').', 'AbortError');
          const text = await res.text();
          let u;
          try { u = makeBlobUrl(new Blob([text], { type: 'text/javascript' })); }
          catch { u = 'data:text/javascript;base64,' + btoa(unescape(encodeURIComponent(text))); }
          try { return await NW.call(self, u, opts); }
          catch (e) {   // blob: may be refused in some worklet contexts; a data: url is always loadable
            return NW.call(self, 'data:text/javascript;base64,' + btoa(unescape(encodeURIComponent(text))), opts);
          }
        })();
      };
    }
  }

