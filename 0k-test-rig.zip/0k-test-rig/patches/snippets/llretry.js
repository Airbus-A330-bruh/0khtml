function zkFresh(){let n=Date.now();if(n-(Z._zkFresh||0)<8000)return;Z._zkFresh=n;try{Z.session=new Kc.HTTPSession}catch(e){}}
async function llRetry0(e,t,n,r,i,rec){
  let cfg=globalThis.__zkRetryCfg||{},tries=cfg.tries||3,idem=t===`GET`||t===`HEAD`,err;
  if(!idem)return ll(e,t,n,r,i);
  for(let k=0;k<tries;k++){
    if(i&&i.aborted)return ll(e,t,n,r,i);
    let ttfb=cfg.ttfb||[12e3,2e4,3e4][Math.min(k,2)],ac=new AbortController,onAb=()=>ac.abort(),timer,timedOut=!1;
    i&&i.addEventListener(`abort`,onAb,{once:!0});
    try{
      let p=ll(e,t,n,r,ac.signal);p.catch(()=>{});
      return await Promise.race([p,new Promise((_,rej)=>{timer=setTimeout(()=>{timedOut=!0;ac.abort();rej(Error(`Request "${e.href}" failed with error code 28: no response headers within ${ttfb}ms`))},ttfb)})])
    }catch(x){
      err=x;
      if(i&&i.aborted)throw x;
      let m=String(x&&x.message||x);
      if(!timedOut&&!/error code (6|7|16|18|28|35|52|55|56|92)\b|Failed to fetch|not connected|NetworkError|Timeout/i.test(m))throw x;
      if(k===tries-1)throw x;
      (globalThis.__zkDiagLog||(globalThis.__zkDiagLog=[])).push({u:e.href.slice(0,180),retry:k+1,err:m.slice(0,120),t0:Date.now()});
      zkFresh();
      await new Promise(r=>setTimeout(r,(cfg.backoff??400)*(k+1)*(k+1)))
    }finally{clearTimeout(timer);i&&i.removeEventListener(`abort`,onAb)}
  }
  throw err
}
async function llRetry(e,t,n,r,i){
  let D=globalThis.__zkDiagLog||(globalThis.__zkDiagLog=[]),rec={u:e.href.slice(0,180),m:t,t0:Date.now()};
  D.push(rec);if(D.length>600)D.splice(0,D.length-600);
  try{let res=await llRetry0(e,t,n,r,i);rec.ms=Date.now()-rec.t0;rec.s=res.status;return res}
  catch(x){rec.ms=Date.now()-rec.t0;rec.err=String(x&&x.message||x).slice(0,160);throw x}
}
// Console helper: run  copy(JSON.stringify(__zkDiag(),null,1))  in the DevTools console of the 0K tab and send the result.
globalThis.__zkDiag=()=>{
  let L=globalThis.__zkDiagLog||[],now=Date.now(),reqs=L.filter(x=>!x.retry),done=reqs.filter(x=>x.ms!=null),pend=reqs.filter(x=>x.ms==null),bad=done.filter(x=>x.err||x.s>=500),v=globalThis[Symbol.for(`zk.vsw`)];
  return{at:new Date().toISOString(),totals:{requests:reqs.length,pending:pend.length,failed:bad.length,retries:L.length-reqs.length,okMedianMs:(done.filter(x=>!x.err&&x.s<500).map(x=>x.ms).sort((a,b)=>a-b)[done.length>>1])||null},
    pending:pend.map(x=>({u:x.u,m:x.m,waitingMs:now-x.t0})).slice(0,25),
    failed:bad.slice(-25).map(x=>({u:x.u,s:x.s,err:x.err,ms:x.ms})),
    retries:L.filter(x=>x.retry).slice(-25).map(x=>({u:x.u,attempt:x.retry,err:x.err})),
    slowest:done.slice().sort((a,b)=>b.ms-a.ms).slice(0,10).map(x=>({u:x.u,ms:x.ms,s:x.s})),
    pools:v&&v.poolState?v.poolState():null,tunnel:{connected:typeof tl==`function`?tl():null}}
};
