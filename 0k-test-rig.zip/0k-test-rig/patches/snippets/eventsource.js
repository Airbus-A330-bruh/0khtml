  /* ============================================================ EventSource === */
  // The native EventSource would try to load the prefix-form file:// url. Re-implement it on the shim's streaming fetch.
  {
    const shimFetch = window.fetch;
    if (window.EventSource) {
      class ZkEventSource extends EventTarget {
        constructor(url, init) {
          super();
          this._pfx = String(url);
          this.withCredentials = !!(init && init.withCredentials);
          this.readyState = 0;
          this.onopen = this.onmessage = this.onerror = null;
          this._lastId = '';
          this._retry = 3000;
          this._ctl = null;
          let shown = this._pfx;
          try { if (isPfx(shown)) shown = origUrlOf(shown); } catch {}
          Object.defineProperty(this, 'url', { value: shown, enumerable: true });
          setTimeout(() => this._connect(), 0);
        }
        _fire(type, ev) {
          const h = this['on' + type];
          if (typeof h === 'function') { try { h.call(this, ev); } catch (e) { console.error(e); } }
          this.dispatchEvent(ev);
        }
        _fail(fatal) {
          if (this.readyState === 2) return;
          if (fatal) { this.readyState = 2; this._fire('error', new Event('error')); return; }
          this.readyState = 0;
          this._fire('error', new Event('error'));
          setTimeout(() => this._connect(), this._retry);
        }
        async _connect() {
          if (this.readyState === 2) return;
          this.readyState = 0;
          const ctl = (this._ctl = new AbortController());
          try {
            const headers = { Accept: 'text/event-stream', 'Cache-Control': 'no-cache' };
            if (this._lastId) headers['Last-Event-ID'] = this._lastId;
            const res = await shimFetch.call(window, this._pfx, { headers, signal: ctl.signal });
            if (res.status !== 200 || !/text\/event-stream/i.test(res.headers.get('content-type') || '')) return this._fail(true);
            this.readyState = 1;
            this._fire('open', new Event('open'));
            const rd = res.body.getReader();
            const dec = new TextDecoder();
            let buf = '', data = '', type = '', id = this._lastId;
            const origin = (() => { try { return new URL(this.url).origin; } catch { return ''; } })();
            for (;;) {
              const { done, value } = await rd.read();
              if (done) break;
              buf += dec.decode(value, { stream: true });
              for (;;) {
                const m = /\r\n|\n|\r/.exec(buf);
                if (!m || (m[0] === '\r' && m.index === buf.length - 1)) break; // a lone trailing CR may be half of a CRLF
                const line = buf.slice(0, m.index);
                buf = buf.slice(m.index + m[0].length);
                if (line === '') {
                  if (data !== '') {
                    const t = type || 'message';
                    this._lastId = id;
                    this._fire(t, new MessageEvent(t, { data: data.endsWith('\n') ? data.slice(0, -1) : data, origin, lastEventId: id }));
                  }
                  data = ''; type = '';
                  continue;
                }
                if (line[0] === ':') continue;
                const c = line.indexOf(':');
                const f = c < 0 ? line : line.slice(0, c);
                let v = c < 0 ? '' : line.slice(c + 1);
                if (v[0] === ' ') v = v.slice(1);
                if (f === 'data') data += v + '\n';
                else if (f === 'event') type = v;
                else if (f === 'id') { if (!v.includes('\0')) id = v; }
                else if (f === 'retry' && /^\d+$/.test(v)) this._retry = +v;
              }
            }
            this._fail(false); // server closed the stream: reconnect after the retry delay
          } catch (e) {
            if (this.readyState !== 2) this._fail(false);
          }
        }
        close() { this.readyState = 2; try { this._ctl && this._ctl.abort(); } catch {} }
      }
      for (const [k, v] of [['CONNECTING', 0], ['OPEN', 1], ['CLOSED', 2]]) {
        Object.defineProperty(ZkEventSource, k, { value: v });
        Object.defineProperty(ZkEventSource.prototype, k, { value: v });
      }
      window.EventSource = ZkEventSource;
    }
  }

