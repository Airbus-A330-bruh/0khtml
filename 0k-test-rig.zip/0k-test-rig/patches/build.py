import sys, os
from patchlib import Doc
HERE = os.path.dirname(os.path.abspath(__file__))
if len(sys.argv) < 3:
    raise SystemExit('usage: python3 build.py <base.html> <out.html>')
d = Doc(sys.argv[1])

# ---------------------------------------------------------------- Scramjet core
d.edit('zk-src-sj',
  '?new URL(n.href,e.url.origin).href:e.url.origin',
  '?new URL(n.getAttribute("href")||n.href,e.url.href).href:e.url.href',
  'document.baseURI must be the document URL (upstream fix), not just the origin')

# ---------------------------------------------------------------- shim: pristine natives + fetch(Request) + Cache(Request)
d.edit('zk-src-shim',
"""  const nsa = Element.prototype.setAttribute;""",
"""  // Scramjet traps Request.prototype.url to return the *unrewritten* URL; the shim needs the real (prefix-form) one.
  const NReq = window.Request;
  const reqUrlGet = Object.getOwnPropertyDescriptor(Request.prototype, 'url').get;
  const rawReqUrl = (r) => reqUrlGet.call(r);

  const nsa = Element.prototype.setAttribute;""",
  'capture pristine Request + raw url getter')

d.edit('zk-src-shim',
"      url = input instanceof Request ? input.url : typeof input === 'string' ? input : String(input);",
"      url = input instanceof Request ? rawReqUrl(input) : typeof input === 'string' ? input : String(input);",
  'fetch(Request) used the trapped (unrewritten) url -> fell through to native fetch with file://')

d.edit('zk-src-shim',
"        if (r instanceof Request) return isPfx(r.url) ? new Request(origUrlOf(r.url), { method: r.method, headers: r.headers }) : r;",
"        if (r instanceof Request) return isPfx(rawReqUrl(r)) ? new NReq(origUrlOf(rawReqUrl(r)), { method: r.method, headers: r.headers }) : r;",
  'Cache API: Request objects keyed by real url using the pristine Request constructor')

d.edit('zk-src-shim',
"            return new Request(vsw.toPfx(r.url), { method: r.method, headers: r.headers });",
"            return new NReq(vsw.toPfx(r.url), { method: r.method, headers: r.headers });",
  'Cache.keys: pristine Request constructor')

# ---------------------------------------------------------------- shim: new Audio(url)
d.edit('zk-src-shim',
"  /* ============================================================ workers === */",
"""  /* ============================================================ Audio() === */
  // Scramjet rewrites new Audio(url)'s argument to a prefix-form URL and the native constructor then sets the
  // media element's src attribute directly, skipping our lazy loader. Route it through the .src setter instead.
  const NativeAudio = window.Audio;
  if (NativeAudio) {
    const A = function Audio(src) {
      const a = new NativeAudio();
      // Scramjet already rewrote src to prefix-form; give the setter the original so it takes the normal lazy-load path
      if (src !== undefined) { const u = String(src); a.src = isPfx(u) ? origUrlOf(u) : u; }
      return a;
    };
    A.prototype = NativeAudio.prototype;
    Object.setPrototypeOf(A, NativeAudio);
    window.Audio = A;
  }

  /* ============================================================ workers === */""",
  'new Audio(url)')

# ---------------------------------------------------------------- app bundle: websocket subprotocol + receive drain
d.edit('module',
"s.onopen=()=>r(``,``)",
"s.onopen=()=>r(s.protocol||``,``)",
  'report the sub-protocol the server actually selected (captured from the handshake response, see libcurl patch below)')

d.edit('module',
"function ul(e,t,n,r,i,a,o){let s,c=!1;",
"function ul(e,t,n,r,i,a,o){let s,c=!1;",
  'anchor check')

# libcurl.js WebSocket: (1) one recv() per setInterval tick (~4ms clamp => ~250 msg/s ceiling): drain per tick instead;
# (2) the handshake headers callback was an empty no-op: use it to learn the sub-protocol the server selected.
d.edit('module',
"connect(){let e=()=>{},t=()=>{},n=e=>{e===0?(this.connected=!0,this.recv_loop=setInterval(()=>{let e=this.recv();e!==null&&this.onmessage(e)},0)",
"connect(){let e=()=>{},t=b=>{try{let m=/^sec-websocket-protocol:\\s*([^\\r\\n]+)/i.exec(new TextDecoder().decode(b));m&&(this._zkProto=m[1].trim())}catch{}},n=e=>{e===0?(this.connected=!0,this.recv_loop=setInterval(()=>{for(let k=0;k<256;k++){let e=this.recv();if(e===null||!this.connected)break;this.onmessage(e)}},0)",
  'libcurl ws: drain the socket each tick (was one message per ~4ms) + capture negotiated sub-protocol')


# =================================================================== ROUND 2: workers + media
# ---- vsw: stash for blob/data worker sources, importScripts prefetch
d.edit('zk-src-vsw',
"""  /** Worker script text (+ the asset scripts its prelude imports); delivered as text since workers can't read our blobs. */
  vsw.workerSource = async (pfxUrl, clientReal) => {
    const { res, finalRaw } = await request(pfxUrl, { dest: 'worker', clientReal });
    if (res.status >= 400) throw new Error('HTTP ' + res.status);
    const text = await bodyText(res);
    const texts = {};
    const at = vsw.assetTexts || {};
    for (const u in at) if (text.includes(u)) texts[u] = at[u]();
    const key = 'zk-worker-main';
    texts[key] = text;
    let real = '';
    try { real = fromPfx(finalRaw); } catch {}
    return { key, texts, real };
  };""",
"""  /* blob:/data: worker sources cannot be fetched by the controller. The shim reads them in-page and stashes the text
   * here; the 0K transport serves it back from the synthetic host below, so it takes the normal rewrite path. */
  const stash = new Map();
  vsw.blobHost = 'zkblob.0k';
  vsw.stash = (text, type) => {
    const id = Math.random().toString(36).slice(2) + Date.now().toString(36);
    stash.set(id, { text, type: type || 'text/javascript' });
    setTimeout(() => stash.delete(id), 120000);
    return id;
  };
  vsw.takeStash = (pathname) => stash.get(String(pathname).replace(/^\\//, '').replace(/\\.[a-z]+$/, '')) || null;

  /** importScripts() is synchronous, so every script a worker will import has to be in hand before it starts.
   *  Pre-fetch the string-literal arguments (also those hidden in Scramjet's base64 "encapsulated" body). */
  const IS_RE = /\\bimportScripts\\s*\\(([^)]*)\\)/g;
  const STR_RE = /(['"`])((?:\\\\.|(?!\\1)[^\\\\\\n])*)\\1/g;
  const B64_RE = /data:text\\/javascript(?:;charset=utf-8)?;base64,([A-Za-z0-9+/=]+)/g;
  const b64text = (b) => { try { return new TextDecoder().decode(Uint8Array.from(atob(b), (c) => c.charCodeAt(0))); } catch { return ''; } };
  async function prefetchImports(text, base, texts, clientReal, depth) {
    if (depth > 4) return;
    const bodies = [text];
    let b;
    B64_RE.lastIndex = 0;
    while ((b = B64_RE.exec(text))) bodies.push(b64text(b[1]));
    const want = new Set();
    for (const body of bodies) {
      if (!body.includes('importScripts')) continue;
      let m;
      IS_RE.lastIndex = 0;
      while ((m = IS_RE.exec(body))) {
        let s;
        STR_RE.lastIndex = 0;
        while ((s = STR_RE.exec(m[1]))) {
          const spec = s[2];
          if (!spec || (s[1] === '`' && spec.includes('${')) || /^(data|blob):/.test(spec)) continue;
          try {
            want.add(spec.startsWith(prefixHref) ? spec : toPfx(new URL(spec, base).href));
          } catch {}
        }
      }
    }
    await Promise.all([...want].filter((u) => !(u in texts) && Object.keys(texts).length < 48).map(async (u) => {
      texts[u] = '';
      try {
        const { res, finalRaw } = await request(u, { dest: 'script', clientReal });
        if (res.status >= 400) return;
        const t = await bodyText(res);
        texts[u] = t;
        let real = base;
        try { real = fromPfx(finalRaw); } catch {}
        await prefetchImports(t, real, texts, clientReal, depth + 1);
      } catch (e) {
        console.warn('[0k/file] importScripts prefetch failed', u.slice(prefixHref.length, prefixHref.length + 160), e && e.message);
        delete texts[u];
      }
    }));
  }

  /** Worker script text (+ the asset scripts its prelude imports); delivered as text since workers can't read our blobs. */
  vsw.workerSource = async (pfxUrl, clientReal) => {
    const { res, finalRaw } = await request(pfxUrl, { dest: 'worker', clientReal });
    if (res.status >= 400) throw new Error('HTTP ' + res.status);
    const text = await bodyText(res);
    const texts = {};
    const at = vsw.assetTexts || {};
    for (const u in at) if (text.includes(u)) texts[u] = at[u]();
    const key = 'zk-worker-main';
    texts[key] = text;
    let real = '';
    try { real = fromPfx(finalRaw); } catch {}
    await prefetchImports(text, real || clientReal, texts, clientReal, 0);
    return { key, texts, real };
  };""",
 'worker source: stash for blob/data workers + importScripts prefetch')

# ---- shim: worker boot (importScripts lookup tolerant to query/hash) + blob/data workers
d.edit('zk-src-shim',
"""      const local=u=>{if(u.startsWith(PFX)&&/^(blob:|data:)/.test(u.slice(PFX.length)))u=u.slice(PFX.length);const t=texts[u];return t==null?u:URL.createObjectURL(new Blob([t],{type:'text/javascript'}))};
      self.importScripts=function importScripts(...urls){return nis.apply(self,urls.map(u=>local(String(u))))};""",
"""      const norm=u=>{const i=u.search(/[?#]/);return i<0?u:u.slice(0,i)};
      const byNorm={};for(const k in texts)byNorm[norm(k)]=k;
      const made={};
      const local=u=>{if(u.startsWith(PFX)&&/^(blob:|data:)/.test(u.slice(PFX.length)))u=u.slice(PFX.length);let k=u in texts?u:byNorm[norm(u)];if(k==null||texts[k]==null||texts[k]==='')return u;return made[k]||(made[k]=URL.createObjectURL(new Blob([texts[k]],{type:'text/javascript'})))};
      self.importScripts=function importScripts(...urls){const mapped=urls.map(u=>local(String(u)));for(const m of mapped)if(m.startsWith(PFX))console.error('[0k/file] importScripts() of a script that could not be pre-fetched (dynamic URL?):',m.slice(PFX.length,PFX.length+200));return nis.apply(self,mapped)};""",
 'worker boot: importScripts lookup by normalised url, blob cache, clear error')

d.edit('zk-src-shim',
"""    const W = function Worker(url, opts) {
      const u = String(url);
      const rest = u.slice(PFX.length);
      if (!isPfx(u) || /^(blob:|data:)/.test(rest) || (opts && opts.type === 'module')) return new NativeWorker(url, opts);
      const boot = vsw.blobUrl(WORKER_BOOT(PFX), 'text/javascript');
      const w = new NativeWorker(boot, opts);""",
"""    const W = function Worker(url, opts) {
      const u = String(url);
      const rest = u.slice(PFX.length);
      if (!isPfx(u) || (opts && opts.type === 'module')) return new NativeWorker(url, opts);
      const boot = vsw.blobUrl(WORKER_BOOT(PFX), 'text/javascript');
      const w = new NativeWorker(boot, opts);""",
 'Worker(): blob:/data: urls now take the proxied path instead of being passed through as file:// urls')

d.edit('zk-src-shim',
"""      vsw.workerSource(u, cur()).then((r) => {
        nativeWorkerPost.call(w, { __zkInit: true, url: r.key, texts: r.texts, real: r.real, port: mc.port2 }, [mc.port2]);
      });
      return w;""",
"""      (async () => {
        let src = u;
        if (/^(blob:|data:)/.test(rest)) {
          // the controller cannot fetch blob:/data: itself: read the script here and hand it over via the stash
          const clean = rest.replace(/\\?dest=(?:worker|sharedworker)(?:&type=module)?$/, '');
          const text = await (await nfetch.call(window, clean)).text();
          src = vsw.toPfx('https://' + vsw.blobHost + '/' + vsw.stash(text, 'text/javascript') + '.js') + '?dest=worker';
        }
        const r = await vsw.workerSource(src, cur());
        if (/^(blob:|data:)/.test(rest)) r.real = cur();
        nativeWorkerPost.call(w, { __zkInit: true, url: r.key, texts: r.texts, real: r.real, port: mc.port2 }, [mc.port2]);
      })().catch((err) => {
        console.error('[0k/file] worker start failed', err);
        try { w.dispatchEvent(new ErrorEvent('error', { message: String(err && err.message || err) })); } catch {}
      });
      return w;""",
 'Worker(): fetch blob/data source in-page, stash, request via zkblob.0k')

# ---- app bundle: serve stashed blobs from the synthetic host
d.edit('module',
"if(s){let t=`0k-site/${e.host.replace(`.0k`,``)}`",
"if(t==`GET`&&e.host==`zkblob.0k`){let v=globalThis[Symbol.for(`zk.vsw`)].takeStash(e.pathname);return v?Mi(200,`OK`,new Headers({'content-type':v.type}),v.text):Mi(404,`Not Found`,new Headers,`blob expired`)}if(s){let t=`0k-site/${e.host.replace(`.0k`,``)}`",
 'transport: serve stashed blob worker sources')

# ---- shim: media elements wait for their lazily-loaded src before play()/load()
d.edit('zk-src-shim',
"""  wrapProp('HTMLMediaElement', 'src', binHandler('bin'), ['audio', 'video']);""",
"""  // The media src is loaded lazily (fetch -> blob url); until it lands the element has no source, so an immediate
  // play()/load() (new Audio(url).play(), video.src=...; video.play()) would fail. Make those wait for it.
  const MEDIA_PENDING = new WeakMap(); // el -> {p, done}
  const mediaSettle = (el) => {
    const m = MEDIA_PENDING.get(el);
    if (m) { MEDIA_PENDING.delete(el); m.done(); }
  };
  wrapProp('HTMLMediaElement', 'src', function (pfx, set) {
    mediaSettle(this);
    let done;
    const p = new Promise((r) => (done = r));
    MEDIA_PENDING.set(this, { p, done });
    return loadInto(this, 'src', pfx, 'bin', (url) => {
      set(url);
      if (MEDIA_PENDING.get(this) && MEDIA_PENDING.get(this).p === p) mediaSettle(this);
    });
  }, ['audio', 'video']);
  {
    const MP = HTMLMediaElement.prototype;
    const nplay = MP.play, nload = MP.load;
    MP.play = function play() {
      const m = MEDIA_PENDING.get(this);
      return m ? m.p.then(() => nplay.call(this)) : nplay.call(this);
    };
    MP.load = function load() {
      const m = MEDIA_PENDING.get(this);
      if (m) m.p.then(() => nload.call(this));
      else nload.call(this);
    };
  }""",
 'media: play()/load() wait for the lazy src')

# a plain (non-pfx) src assignment must also release waiters
d.edit('zk-src-shim',
"""        } else clearOrig(this, prop);
        d.set.call(this, v);""",
"""        } else {
          clearOrig(this, prop);
          if (typeof mediaSettle === 'function' && prop === 'src') mediaSettle(this);
        }
        d.set.call(this, v);""",
 'media: release waiters when src is replaced by a non-lazy value')

# =================================================================== ROUND 3: WebSocket / transport inside workers
d.edit('zk-src-shim',
"""      const pending=new Map();let id=0;
      port.onmessage=m=>""",
"""      // Scramjet's transport (WebSocket etc.) inside the worker: hand its port to the page, which wires it to the controller.
      const ppost=MessagePort.prototype.postMessage;
      self[Symbol.for('zk.attachTransport')]=p=>ppost.call(port,{attach:p},[p]);
      const pending=new Map();let id=0;
      port.onmessage=m=>""",
 'worker boot: zk.attachTransport -> parent')

d.edit('zk-src-shim',
"""      mc.port1.onmessage = async (e) => {
        const m = e.data;
        try {""",
"""      mc.port1.onmessage = async (e) => {
        const m = e.data;
        if (m && m.attach) { try { vsw.attachTransport(m.attach); } catch (err) { console.error('[0k/file] worker transport attach failed', err); } return; }
        try {""",
 'Worker(): parent routes a worker transport port to the controller')

# =================================================================== ROUND 4: real transport for workers (WebSocket/XHR) + blob noise
d.edit('zk-src-sj',
'function a(e,t,r){let n=new URL(e.substring(5));return"blob:"+r.origin.origin+n.pathname}function i(e,t,r){let n=new URL(e.substring(5));return"blob:"+t.prefix.origin+n.pathname}',
'function a(e,t,r){let n;try{n=new URL(e.substring(5))}catch{return e}return"blob:"+r.origin.origin+n.pathname}function i(e,t,r){let n;try{n=new URL(e.substring(5))}catch{return e}return"blob:"+t.prefix.origin+n.pathname}',
 'rewriteBlob threw on blob:null/<uuid> (every blob url under file://) -> tolerate it')

# vsw: expose the controller's real transport; let Scramjet's worker prelude use the worker transport
d.edit('zk-src-vsw',
"  vsw.isPfx = isPfx;\n",
"  vsw.rawTransport = () => ctl.transport;\n  vsw.isPfx = isPfx;\n",
 'vsw.rawTransport')

d.edit('zk-src-vsw',
"""    const text = await bodyText(res);
    const texts = {};
    const at = vsw.assetTexts || {};
    for (const u in at) if (text.includes(u)) texts[u] = at[u]();
    const key = 'zk-worker-main';""",
"""    let text = await bodyText(res);
    // Scramjet's stock worker prelude hard-codes `transport: null`; give it the bridge the worker boot provides
    text = text.replace(/transport:\\s*null,/, "transport: self[Symbol.for('zk.workerTransport')] || null,");
    const texts = {};
    const at = vsw.assetTexts || {};
    for (const u in at) if (text.includes(u)) texts[u] = at[u]();
    const key = 'zk-worker-main';""",
 'worker prelude: use the bridged transport')

# shim: worker boot defines the bridged transport; raw rpc replies
d.edit('zk-src-shim',
"""      self[Symbol.for('zk.attachTransport')]=p=>ppost.call(port,{attach:p},[p]);
      const pending=new Map();let id=0;""",
"""      self[Symbol.for('zk.attachTransport')]=p=>ppost.call(port,{attach:p},[p]);
      const pending=new Map();let id=0;
      // Transport for Scramjet's client inside the worker (WebSocket, XHR): bridged to the controller's transport via the page.
      self[Symbol.for('zk.workerTransport')]={ready:true,async init(){},meta(){return{}},
        connect(url,protocols,headers,onopen,onmessage,onclose,onerror){
          const ch=new MessageChannel(),p1=ch.port1;
          ppost.call(port,{wsConnect:true,url:String(url.href||url),protocols:protocols||[],headers:headers||[],port:ch.port2},[ch.port2]);
          p1.onmessage=e=>{const m=e.data;
            if(m.type==='open')onopen(m.protocol||'',m.extensions||'');
            else if(m.type==='data')onmessage(m.data);
            else if(m.type==='close')onclose(m.code,m.reason);
            else if(m.type==='error')onerror(m.error)};
          return [d2=>ppost.call(p1,{type:'data',data:d2},d2 instanceof ArrayBuffer?[d2]:[]),(c,r)=>ppost.call(p1,{type:'close',code:c,reason:r})];
        },
        request(remote,method,body,headers){
          return new Promise((res,rej)=>{const i=++id;pending.set(i,{res,rej,raw:true});
            const b=body instanceof ArrayBuffer?body:null;
            ppost.call(port,{rpcRequest:true,id:i,remote:String(remote.href||remote),method,headers:[...(headers||[])],body:b},b?[b]:[])});
        }};""",
 'worker boot: bridged transport object')

d.edit('zk-src-shim',
"        else p.res(new Response([101,204,205,304].includes(r.status)?null:r.body,{status:r.status,statusText:r.statusText,headers:r.headers}))};",
"        else if(p.raw)p.res({status:r.status,statusText:r.statusText,headers:r.headers,body:r.body});\n        else p.res(new Response([101,204,205,304].includes(r.status)?null:r.body,{status:r.status,statusText:r.statusText,headers:r.headers}))};",
 'worker boot: raw rpc replies')

d.edit('zk-src-shim',
"""        if (m && m.attach) { try { vsw.attachTransport(m.attach); } catch (err) { console.error('[0k/file] worker transport attach failed', err); } return; }""",
"""        if (m && m.attach) { try { vsw.attachTransport(m.attach); } catch (err) { console.error('[0k/file] worker transport attach failed', err); } return; }
        if (m && m.wsConnect) {
          const out = m.port;
          const post = (msg, tr) => { try { portPost.call(out, msg, tr || []); } catch {} };
          try {
            const [send, close] = vsw.rawTransport().connect(new URL(m.url), m.protocols, m.headers,
              (proto, ext) => post({ type: 'open', protocol: proto, extensions: ext }),
              (data) => post({ type: 'data', data }, data instanceof ArrayBuffer ? [data] : []),
              (code, reason) => post({ type: 'close', code, reason }),
              (error) => post({ type: 'error', error: String(error) }));
            out.onmessage = (ev) => { const d = ev.data; if (d.type === 'data') send(d.data); else if (d.type === 'close') close(d.code, d.reason); };
          } catch (err) { post({ type: 'error', error: String(err && err.message || err) }); }
          return;
        }
        if (m && m.rpcRequest) {
          try {
            const r = await vsw.rawTransport().request(new URL(m.remote), m.method, m.body, m.headers, undefined);
            const buf = r.body == null ? null : r.body instanceof ArrayBuffer ? r.body : await new Response(r.body).arrayBuffer();
            portPost.call(mc.port1, { id: m.id, status: r.status, statusText: r.statusText, headers: r.headers, body: buf }, buf ? [buf] : []);
          } catch (err) { portPost.call(mc.port1, { id: m.id, error: String(err && err.message || err) }); }
          return;
        }""",
 'Worker(): parent bridges worker WebSocket/XHR to the controller transport')

# =================================================================== ROUND 5: import maps, inline modules, bare specifiers
d.edit('zk-src-vsw',
"""  const IMPORT_RE = /(?:\\bimport|\\bexport)""",
"""  /* ---- import maps: Scramjet rewrites the map's values to prefix urls (which the browser can't load from file://).
   * We keep the parsed map per document and resolve bare specifiers ourselves, at the source level, into prefix urls
   * that the module-graph machinery below already knows how to turn into blobs. */
  const docMaps = new Map(); // doc url -> { imports: { key: prefixUrl } }
  const dkey = (u) => String(u || '').split('#')[0];
  function bareToPfx(spec, docReal) {
    const mp = docMaps.get(dkey(docReal));
    if (!mp) return null;
    const im = mp.imports;
    if (Object.prototype.hasOwnProperty.call(im, spec)) return im[spec];
    let best = null;
    for (const k in im) if (k.endsWith('/') && spec.startsWith(k) && (!best || k.length > best.length)) best = k;
    if (!best) return null;
    try {
      const dir = fromPfx(im[best]);
      return toPfx(new URL(spec.slice(best.length), dir.endsWith('/') ? dir : dir + '/').href);
    } catch { return null; }
  }
  vsw.resolveBare = bareToPfx;
  const NOT_BARE = /^(?:\\.{0,2}\\/|[a-zA-Z][a-zA-Z0-9+.-]*:)/;
  function rewriteBare(text, docReal) {
    if (!docMaps.has(dkey(docReal))) return text;
    return text.replace(IMPORT_RE, (all, q, s1, q2, s2) => {
      const spec = s1 || s2;
      if (!spec || NOT_BARE.test(spec)) return all;
      const p = bareToPfx(spec, docReal);
      return p ? all.replace(spec, p) : all;
    });
  }
  const IMPORT_RE = /(?:\\bimport|\\bexport)""",
 'import maps: per-document map + bare specifier resolution')

d.edit('zk-src-vsw',
"      if (kind === 'module') text = absolutizeSpecifiers(text);",
"      if (kind === 'module') text = rewriteBare(absolutizeSpecifiers(text), clientReal);",
 'modules: resolve bare specifiers through the document import map')

d.edit('zk-src-vsw',
"""    let moduleRoots = [];

    for (const t of toks) {
      if (typeof t === 'string') continue;
      if (t.rawtext) {""",
"""    let moduleRoots = [];
    let inlineModule = false;

    // import maps first: they decide how every later bare specifier resolves
    for (let i = 0; i < toks.length; i++) {
      const t = toks[i];
      if (typeof t === 'string' || t.tag !== 'script' || (ZK.getAttr(t, 'type') || '').toLowerCase() !== 'importmap') continue;
      const rt = toks[i + 1];
      if (!rt || rt.rawtext !== 'script') continue;
      try {
        const j = JSON.parse(rt.text);
        const prev = docMaps.get(dkey(docReal));
        docMaps.set(dkey(docReal), { imports: { ...(prev ? prev.imports : {}), ...(j.imports || {}) } });
      } catch (e) { console.warn('[0k/file] bad import map', e && e.message); }
      rt.text = '{}'; // the native map would carry unloadable file:// urls; we re-emit a working one below
      rt.dirty = true;
    }

    const prepInlineModule = async (t) => {
      const text = rewriteBare(absolutizeSpecifiers(t.text), docReal);
      if (text !== t.text) { t.text = text; t.dirty = true; }
      const specs = new Set();
      let m;
      IMPORT_RE.lastIndex = 0;
      while ((m = IMPORT_RE.exec(text))) {
        const sp = m[2] || m[4];
        if (sp && sp.startsWith(prefixHref) && !/^(data|blob):/.test(sp.slice(prefixHref.length))) specs.add(sp);
      }
      await Promise.all([...specs].map((sp) => moduleGraph(sp, docReal, importMap)));
    };

    for (const t of toks) {
      if (typeof t === 'string') continue;
      if (t.rawtext) {
        if (t.rawtext === 'script' && inlineModule) {
          inlineModule = false;
          jobs.push(prepInlineModule(t));
        }""",
 'processHtml: import map prescan + inline module preparation')

d.edit('zk-src-vsw',
"""      if (tag === 'script') {
        const src = ZK.getAttr(t, 'src');""",
"""      if (tag === 'script') {
        inlineModule = false;
        const src = ZK.getAttr(t, 'src');""",
 'processHtml: reset inline-module flag per script tag')

d.edit('zk-src-vsw',
"""        } else if (src === null) {
          // inline module scripts can import prefix URLs too
        }""",
"""        } else if (src === null) {
          inlineModule = (ZK.getAttr(t, 'type') || '').toLowerCase() === 'module';
        }""",
 'processHtml: inline module scripts')

d.edit('zk-src-vsw',
"""    for (const r of results) if (r.status === 'rejected') console.warn('[0k/file] prepass job failed', r.reason);
""",
"""    for (const r of results) if (r.status === 'rejected') console.warn('[0k/file] prepass job failed', r.reason);

    // import-map entries: build graphs for exact keys so a plain native import('three') works too, and alias the bare names
    const dm = docMaps.get(dkey(docReal));
    if (dm) {
      const exact = Object.entries(dm.imports).filter(([k, v]) => !k.endsWith('/') && isPfx(v) && !/^(data|blob):/.test(v.slice(prefixHref.length)));
      await Promise.all(exact.slice(0, 16).map(([k, v]) => moduleGraph(v, docReal, importMap).catch(() => {})));
      for (const [k, v] of exact) if (importMap[v]) importMap[k] = importMap[v];
    }
""",
 'processHtml: import-map exact entries -> blob graph + aliases')

# shim: dynamic import of blob:/data: urls and bare specifiers
d.edit('zk-src-shim',
"""  window[Symbol.for('zk.import')] = async (url, nativeImport) => {
    const { map } = await vsw.moduleGraph(url, cur());""",
"""  window[Symbol.for('zk.import')] = async (url, nativeImport) => {
    url = String(url);
    // Scramjet hands us a prefix-form blob:/data: url with "?type=module" appended; that suffix corrupts the url
    const r0 = isPfx(url) ? url.slice(PFX.length) : url;
    if (/^(blob:|data:)/.test(r0)) return nativeImport(r0.replace(/\\?type=module$/, ''));
    if (!isPfx(url)) {
      const bare = vsw.resolveBare && vsw.resolveBare(url, cur());
      if (!bare) return nativeImport(url);   // plain native specifier (exact import-map key etc.)
      url = bare;
    }
    const { map } = await vsw.moduleGraph(url, cur());""",
 'dynamic import(): blob/data urls and bare specifiers')

# =================================================================== ROUND 6: rewriter output fix
d.edit('zk-src-sj',
'console.error("oxc parse error",e);return o}catch(i){',
'console.error("oxc parse error",e);return function(o){let B=o instanceof Uint8Array,x=B?new TextDecoder().decode(o):o;if(typeof x!="string"||x.indexOf("$scramjet$")<0)return o;let f=x.replace(/\\b(return|typeof|void|throw|delete|await|yield|new|case|else|do|in|of|instanceof|extends)(?=\\$scramjet\\$)/g,"$1 ");return f===x?o:B?new TextEncoder().encode(f):f}(o)}catch(i){',
 'rewriter bug: `return(x).postMessage()` -> `return$scramjet$wrappostmessage(...)` (keyword fused with injected identifier)')

# bare specifiers in dynamic import(): route through the hook as well (they previously bypassed it)
d.edit('zk-src-sj',
'r(`${e.rewriteUrl(s)}?type=module`)):r(n)}',
'r(`${e.rewriteUrl(s)}?type=module`)):(globalThis[Symbol.for("zk.import")]?globalThis[Symbol.for("zk.import")](n,r):r(n))}',
 'dynamic import(): bare specifiers reach the import-map aware hook')

# =================================================================== ROUND 8: cookies shared with the controller, WebSocket handshake cookie, ws.protocol
d.edit('zk-src-vsw',
"  vsw.rawTransport = () => ctl.transport;\n",
"  vsw.rawTransport = () => ctl.transport;\n  vsw.cookieJar = () => globalThis.__zkJar || ctl.cookieJar;\n  vsw.poolState = () => Object.fromEntries(Object.entries(pools).map(([k, p]) => [k, { active: p.active, queued: p.queue.length, max: p.max }]));\n",
 'vsw.cookieJar')

d.edit('zk-src-inject',
"let m=new c;m.load(t);",
"let m=function(){try{for(let w=globalThis;;){let v;try{v=w[Symbol.for(\"zk.vsw\")]}catch(e){}if(v&&v.cookieJar)return v.cookieJar();if(w.parent===w)break;w=w.parent}}catch(e){}let x=new c;x.load(t);return x}();",
 'frames share the controller cookie jar (was a stale snapshot; document.cookie and request cookies disagreed)')

d.edit('zk-src-sj',
'let a=e.bare.createWebSocket(n.args[0],n.args[1],[["User-Agent",t.navigator.userAgent],["Origin",e.url.origin]]),i=',
'let a=e.bare.createWebSocket(n.args[0],n.args[1],[["User-Agent",t.navigator.userAgent],["Origin",e.url.origin],...(()=>{try{let c=e.context.cookieJar.getCookies(e.url,!1);return c?[["Cookie",c]]:[]}catch(_){return[]}})()]),i=',
 'WebSocket handshake carries the cookies (upstream added this later)')

d.edit('zk-src-sj',
'a.addEventListener("open",()=>{o(new Event("open"))}),a.addEventListener("close",e=>{o(new CloseEvent("close",e))})',
'a.addEventListener("open",()=>{i.protocol=a.protocol||"",i.extensions=a.extensions||"",o(new Event("open"))}),a.addEventListener("close",e=>{o(new CloseEvent("close",e))})',
 'ws.protocol / ws.extensions were never populated at page level')

# =================================================================== ROUND 9: WebSocket handshake headers never reached the server
d.edit('module',
"s=new Kc.WebSocket(e.toString(),t,{headers:n})",
"s=new Kc.WebSocket(e.toString(),t,{headers:Array.isArray(n)?Object.fromEntries(n):n||{}})",
 'ws: Scramjet passes headers as [[name,value],...] but libcurl.js needs {name:value}; the array was silently dropped (no Origin / Cookie / Sec-WebSocket-Protocol ever sent)')

d.edit('module',
"get protocol(){return this.protocols[0]||``}get extensions(){return``}}class ci extends ii",
"get protocol(){return(this.socket&&this.socket._zkProto)||(this.status===this.OPEN?``:this.protocols[0]||``)}get extensions(){return``}}class ci extends ii",
 'libcurl ws: protocol getter prefers the server-selected protocol (it only ever guessed protocols[0])')

# =================================================================== ROUND 11: module workers
d.edit('zk-src-vsw',
"""  vsw.moduleGraph = async (rootPfx, clientReal) => {""",
"""  /** Module workers can't load file:// urls, import maps or importScripts. Ship the module graph as text; the worker
   *  boot (a classic worker carrying Scramjet's normal prelude) rebuilds it from worker-local blob urls. */
  vsw.moduleWorkerSource = async (rootPfx, clientReal) => {
    const texts = {}, deps = {}, seen = new Set();
    const walk = async (u) => {
      if (seen.has(u)) return;
      seen.add(u);
      const r = await getResource(u, 'module', clientReal);
      if (!r.text) throw new Error('module worker: could not load ' + u.slice(prefixHref.length, prefixHref.length + 160));
      texts[u] = r.text;
      const specs = new Set();
      let m;
      IMPORT_RE.lastIndex = 0;
      while ((m = IMPORT_RE.exec(r.text))) {
        const sp = m[2] || m[4];
        if (sp && sp.startsWith(prefixHref) && !/^(data|blob):/.test(sp.slice(prefixHref.length))) specs.add(sp);
      }
      deps[u] = [...specs];
      await Promise.all([...specs].map(walk));
    };
    await walk(rootPfx);
    const pre = await vsw.workerSource(toPfx('https://' + vsw.blobHost + '/' + vsw.stash('', 'text/javascript') + '.js') + '?dest=worker', clientReal);
    try { pre.real = fromPfx(rootPfx); } catch {}
    pre.module = { root: rootPfx, texts, deps };
    return pre;
  };

  vsw.moduleGraph = async (rootPfx, clientReal) => {""",
 'vsw.moduleWorkerSource')

d.edit('zk-src-shim',
"""      try{self.importScripts(d.url)}catch(err){console.error('[0k/file] worker script failed',err)}
      ready=true;self.removeEventListener('message',early);
      for(const ev of buf)self.dispatchEvent(new MessageEvent('message',{data:(ev.data&&ev.data.$scramjet$messagetype==='worker')?ev.data.$scramjet$data:ev.data,ports:ev.ports?[...ev.ports]:[]}));
      buf.length=0;""",
"""      try{self.importScripts(d.url)}catch(err){console.error('[0k/file] worker script failed',err)}
      const fin=()=>{ready=true;self.removeEventListener('message',early);
        for(const ev of buf)self.dispatchEvent(new MessageEvent('message',{data:(ev.data&&ev.data.$scramjet$messagetype==='worker')?ev.data.$scramjet$data:ev.data,ports:ev.ports?[...ev.ports]:[]}));
        buf.length=0};
      if(d.module){
        // module worker: rebuild the graph from worker-local blob urls (leaves first), then import the root
        (async()=>{try{
          const mt=d.module.texts,dp=d.module.deps,urls={};
          const build=(u,st)=>{if(urls[u])return urls[u];if(st.has(u))throw new Error('circular static import in a module worker is not supported');st.add(u);
            let t=mt[u];for(const sp of (dp[u]||[]))t=t.split(sp).join(build(sp,st));st.delete(u);
            return urls[u]=URL.createObjectURL(new Blob([t],{type:'text/javascript'}))};
          await import(build(d.module.root,new Set()));
        }catch(err){console.error('[0k/file] module worker failed',err)}fin()})();
      }else fin();""",
 'worker boot: module graph loader; messages stay queued until the module has run')

d.edit('zk-src-shim',
"""      if (!isPfx(u) || (opts && opts.type === 'module')) return new NativeWorker(url, opts);
      const boot = vsw.blobUrl(WORKER_BOOT(PFX), 'text/javascript');
      const w = new NativeWorker(boot, opts);""",
"""      if (!isPfx(u)) return new NativeWorker(url, opts);
      const isModule = !!(opts && opts.type === 'module');
      const boot = vsw.blobUrl(WORKER_BOOT(PFX), 'text/javascript');
      const w = new NativeWorker(boot, isModule ? { ...opts, type: 'classic' } : opts);""",
 'Worker(): module workers run inside a classic boot worker')

d.edit('zk-src-shim',
"""        const r = await vsw.workerSource(src, cur());
        if (/^(blob:|data:)/.test(rest)) r.real = cur();
        nativeWorkerPost.call(w, { __zkInit: true, url: r.key, texts: r.texts, real: r.real, port: mc.port2 }, [mc.port2]);""",
"""        let r;
        if (isModule) {
          let root = u.replace(/\\?dest=(?:worker|sharedworker)(?:&type=module)?$/, '');
          if (/^(blob:|data:)/.test(rest)) {
            const clean = rest.replace(/\\?dest=(?:worker|sharedworker)(?:&type=module)?$/, '');
            const text = await (await nfetch.call(window, clean)).text();
            root = vsw.toPfx('https://' + vsw.blobHost + '/' + vsw.stash(text, 'text/javascript') + '.js');
          }
          r = await vsw.moduleWorkerSource(root, cur());
          if (/^(blob:|data:)/.test(rest)) r.real = cur();
        } else {
          r = await vsw.workerSource(src, cur());
          if (/^(blob:|data:)/.test(rest)) r.real = cur();
        }
        nativeWorkerPost.call(w, { __zkInit: true, url: r.key, texts: r.texts, real: r.real, module: r.module, port: mc.port2 }, [mc.port2]);""",
 'Worker(): module worker startup')

# =================================================================== ROUND 12: EventSource
d.edit('zk-src-shim',
"  /* ============================================================ Audio() === */",
open(os.path.join(HERE, 'snippets', 'eventsource.js'), encoding='utf8').read() + "  /* ============================================================ Audio() === */",
 'EventSource implemented on streaming fetch')

# =================================================================== ROUND 13: redirected flag, eager activation of unrendered images
d.edit('zk-src-shim',
"  function makeResponse(r, urlForResponse) {",
"  function makeResponse(r, urlForResponse, requestedUrl) {",
 'makeResponse: accept the requested url')
d.edit('zk-src-shim',
"""    try {
      Object.defineProperty(res, 'url', { value: origUrlOf(urlForResponse || r.url), configurable: true });
    } catch {}
    return res;""",
"""    try {
      Object.defineProperty(res, 'url', { value: origUrlOf(urlForResponse || r.url), configurable: true });
    } catch {}
    try {
      if (requestedUrl) {
        const a = origUrlOf(requestedUrl).split('#')[0], b = origUrlOf(urlForResponse || r.url).split('#')[0];
        Object.defineProperty(res, 'redirected', { value: !!b && a !== b, configurable: true });
      }
    } catch {}
    return res;""",
 'Response.redirected')
d.edit('zk-src-shim',
"      return makeResponse(r);\n    })();\n  };\n\n  const shimFetch = window.fetch;",
"      return makeResponse(r, undefined, url);\n    })();\n  };\n\n  const shimFetch = window.fetch;",
 'fetch: pass requested url for the redirected flag')
d.edit('zk-src-shim',
"      if (io && el.localName === 'img' && el.hasAttribute('data-zk-src') && !el.hasAttribute('data-zk-eager')) io.observe(el);",
"      // lazy-load only images that are actually rendered; IntersectionObserver never fires for display:none / detached ones\n      if (io && el.localName === 'img' && el.hasAttribute('data-zk-src') && !el.hasAttribute('data-zk-eager') && el.getClientRects().length > 0) io.observe(el);",
 'images that are not rendered (hidden preload sprites) must load eagerly')

# =================================================================== ROUND 14: resilience (retries, no poisoned cache, separate pools)
# transport: retry idempotent requests on transient libcurl errors; abandon requests that never answer
d.edit('module',
"function ul(e,t,n,r,i,a,o){let s,c=!1;",
open(os.path.join(HERE, 'snippets', 'llretry.js'), encoding='utf8').read() + "function ul(e,t,n,r,i,a,o){let s,c=!1;",
 'transport: llRetry (GET/HEAD retried on transient errors; TTFB timeout; fresh HTTPSession after a failure)')
d.edit('module',
"try{return await ll(e,t,n,r,i)}catch(e){let t=e instanceof Error?e.message:String(e);return Mi(502,",
"try{return await llRetry(e,t,n,r,i)}catch(e){let t=e instanceof Error?e.message:String(e);return Mi(502,",
 'requestInner uses llRetry')

# vsw: independent limiter pools
d.edit('zk-src-vsw',
"""  let active = 0;
  const queue = [];
  const MAX = 10;
  function limit(fn) {
    return new Promise((res, rej) => {
      const run = () => {
        active++;
        Promise.resolve()
          .then(fn)
          .then(res, rej)
          .finally(() => {
            active--;
            const next = queue.shift();
            if (next) next();
          });
      };
      if (active < MAX) run();
      else queue.push(run);
    });
  }""",
"""  // separate pools: long-lived / hung page requests (SSE, long-poll, stalled fetches) must not starve module+image loads
  const pools = { res: { active: 0, queue: [], max: 10 }, fetch: { active: 0, queue: [], max: 14 } };
  function limit(fn, pool = 'res') {
    const P = pools[pool];
    return new Promise((res, rej) => {
      const run = () => {
        P.active++;
        Promise.resolve()
          .then(fn)
          .then(res, rej)
          .finally(() => {
            P.active--;
            const next = P.queue.shift();
            if (next) next();
          });
      };
      if (P.active < P.max) run();
      else P.queue.push(run);
    });
  }""",
 'limiter: independent pools for page requests and resource loads')
d.edit('zk-src-vsw',
"const { res, finalRaw } = await limit(() => request(pfxUrl, { dest: 'empty', ...o }));",
"const { res, finalRaw } = await limit(() => request(pfxUrl, { dest: 'empty', ...o }), 'fetch');",
 'subRequest uses the page-request pool')

# vsw: failures are never cached; generous backstop (transport retries happen inside)
d.edit('zk-src-vsw',
"""    p = limit(() => withTimeout(loadResource(pfxUrl, kind, clientReal), 45000, pfxUrl));
    p = p.catch((e) => {
      console.warn('[0k/file] resource failed', pfxUrl.slice(prefixHref.length, prefixHref.length + 200), e && e.message);
      return { url: errorBlobUrl(), failed: true };
    });""",
"""    p = limit(() => withTimeout(loadResource(pfxUrl, kind, clientReal), (globalThis.__zkRetryCfg || {}).resTimeout || 120000, pfxUrl));
    p = p.catch((e) => {
      console.warn('[0k/file] resource failed', pfxUrl.slice(prefixHref.length, prefixHref.length + 200), e && e.message);
      if (blobCache.get(key) === p) blobCache.delete(key); // never cache a failure: a later attempt may well succeed
      return { url: errorBlobUrl(), failed: true };
    });""",
 'getResource: do not cache failures; timeout leaves room for the transport retries')

# vsw: a failed module is never pinned into the (first-wins) import map
d.edit('zk-src-vsw',
"""    const r = await getResource(rootPfx, 'module', clientReal);
    map[rootPfx] = r.url;
    if (r.text) {""",
"""    const r = await getResource(rootPfx, 'module', clientReal);
    if (r.failed) return map; // leave it unmapped: import maps are first-wins, so pinning a dead blob would block any retry
    map[rootPfx] = r.url;
    if (r.text) {""",
 'moduleGraph: do not pin failed modules')
d.edit('zk-src-vsw',
"moduleGraph(src, docReal, importMap).then(() => ZK.setAttr(t, 'src', importMap[src])),",
"moduleGraph(src, docReal, importMap).then(() => { if (importMap[src]) ZK.setAttr(t, 'src', importMap[src]); }),",
 'processHtml: only rewrite src when the module loaded')

# shim: a failed dynamic import rejects like a real network failure instead of a confusing MIME error
d.edit('zk-src-shim',
"""    const { map } = await vsw.moduleGraph(url, cur());
    addImportMap(map);""",
"""    const { map } = await vsw.moduleGraph(url, cur());
    if (!map[url]) throw new TypeError('Failed to fetch dynamically imported module: ' + origUrlOf(url));
    addImportMap(map);""",
 'dynamic import(): clear error when the module could not be fetched')

# =================================================================== ROUND 15: import.meta.url
d.edit('zk-src-vsw',
"      if (kind === 'module') text = rewriteBare(absolutizeSpecifiers(text), clientReal);",
"""      if (kind === 'module') {
        text = rewriteBare(absolutizeSpecifiers(text), clientReal);
        // modules are served from blob: urls, so import.meta.url would be a blob url and new URL('./x', import.meta.url) breaks
        if (text.includes('import.meta.url')) {
          let orig = '';
          try { orig = fromPfx(pfxUrl).replace(/\\?type=module$/, ''); } catch {}
          if (orig) text = text.replace(/\\bimport\\.meta\\.url\\b/g, JSON.stringify(orig));
        }
      }""",
 'import.meta.url resolves to the module\'s real url')
d.edit('zk-src-vsw',
"      const text = rewriteBare(absolutizeSpecifiers(t.text), docReal);\n      if (text !== t.text)",
"      let text = rewriteBare(absolutizeSpecifiers(t.text), docReal);\n      if (text.includes('import.meta.url')) text = text.replace(/\\bimport\\.meta\\.url\\b/g, JSON.stringify(String(docReal).split('#')[0]));\n      if (text !== t.text)",
 'inline modules: import.meta.url is the document url')

# =================================================================== ROUND 16: AudioWorklet (Godot audio, Web Audio libraries)
d.edit('zk-src-shim',
"  /* ============================================================ Audio() === */",
open(os.path.join(HERE, 'snippets', 'worklet.js'), encoding='utf8').read() + "  /* ============================================================ Audio() === */",
 'AudioWorklet.addModule goes through the proxy')

# =================================================================== ROUND 17: importScripts(blob:) inside workers (CesiumJS / GeoFS)
d.edit('zk-src-vsw',
"""  async function prefetchImports(text, base, texts, clientReal, depth) {""",
"""  /* A worker may importScripts() a blob: url the *page* created (CesiumJS does this with its 5 MB worker bundle). A worker
   * cannot read the page's blobs, so read it here, run it through the normal rewriter, and cache by content: Cesium builds
   * many workers from identical bundles. */
  const blobRewriteCache = new Map();
  function rewriteBlobScript(text, clientReal) {
    let h = 2166136261;
    for (let i = 0; i < text.length; i++) { h ^= text.charCodeAt(i); h = Math.imul(h, 16777619); }
    const key = text.length + ':' + (h >>> 0);
    let p = blobRewriteCache.get(key);
    if (!p) {
      p = (async () => {
        const id = vsw.stash(text, 'text/javascript');
        const { res } = await request(toPfx('https://' + vsw.blobHost + '/' + id + '.js'), { dest: 'script', clientReal });
        if (res.status >= 400) throw new Error('HTTP ' + res.status);
        return await bodyText(res);
      })();
      blobRewriteCache.set(key, p);
      p.catch(() => blobRewriteCache.delete(key));
    }
    return p;
  }
  async function prefetchImports(text, base, texts, clientReal, depth) {""",
 'blob importScripts: helper')
d.edit('zk-src-vsw',
"          if (!spec || (s[1] === '`' && spec.includes('${')) || /^(data|blob):/.test(spec)) continue;\n          try {\n            want.add(spec.startsWith(prefixHref) ? spec : toPfx(new URL(spec, base).href));\n          } catch {}",
"          if (!spec || (s[1] === '`' && spec.includes('${')) || /^data:/.test(spec)) continue;\n          if (/^blob:/.test(spec)) { want.add(spec); continue; }\n          try {\n            want.add(spec.startsWith(prefixHref) ? spec : toPfx(new URL(spec, base).href));\n          } catch {}",
 'blob importScripts: collect literal blob: specifiers')
d.edit('zk-src-vsw',
"""      texts[u] = '';
      try {
        const { res, finalRaw } = await request(u, { dest: 'script', clientReal });
        if (res.status >= 400) return;
        const t = await bodyText(res);
        texts[u] = t;
        let real = base;
        try { real = fromPfx(finalRaw); } catch {}
        await prefetchImports(t, real, texts, clientReal, depth + 1);""",
"""      texts[u] = '';
      try {
        let t, real = base;
        if (u.startsWith('blob:')) {
          t = await rewriteBlobScript(await (await fetch(u)).text(), clientReal);
        } else {
          const { res, finalRaw } = await request(u, { dest: 'script', clientReal });
          if (res.status >= 400) return;
          t = await bodyText(res);
          try { real = fromPfx(finalRaw); } catch {}
        }
        texts[u] = t;
        await prefetchImports(t, real, texts, clientReal, depth + 1);""",
 'blob importScripts: fetch + rewrite the blob')

# =================================================================== ROUND 18: worker message replay timing (CesiumJS / GeoFS, Emscripten)
d.edit('zk-src-shim',
"""  self.addEventListener('message',early);
})();`;""",
"""  self.addEventListener('message',early);
  let listeners=0;const nael=self.addEventListener;self.addEventListener=function(t,...a){if(t==='message')listeners++;return nael.call(this,t,...a)};
})();`;""",
 'worker boot: count message listeners registered by the worker script')
d.edit('zk-src-shim',
"""      const fin=()=>{ready=true;self.removeEventListener('message',early);
        for(const ev of buf)self.dispatchEvent(new MessageEvent('message',{data:(ev.data&&ev.data.$scramjet$messagetype==='worker')?ev.data.$scramjet$data:ev.data,ports:ev.ports?[...ev.ports]:[]}));
        buf.length=0};""",
"""      const fin=()=>{
        // A real browser delivers queued messages as a later task, after the script's microtasks. Workers such as Cesium's register
        // their handler asynchronously, so replaying synchronously dropped the very first message (Cesium's transfer handshake,
        // after which every task waits forever). Replay in a later task, once a handler exists (bounded wait).
        const run=()=>{ready=true;self.removeEventListener('message',early);
          for(const ev of buf)self.dispatchEvent(new MessageEvent('message',{data:(ev.data&&ev.data.$scramjet$messagetype==='worker')?ev.data.$scramjet$data:ev.data,ports:ev.ports?[...ev.ports]:[]}));
          buf.length=0};
        if(!buf.length){ready=true;self.removeEventListener('message',early);return}
        let tries=0;const tick=()=>{if(self.onmessage||listeners>0||++tries>150)run();else setTimeout(tick,10)};
        setTimeout(tick,0)};""",
 'worker boot: replay buffered messages in a later task, once a handler is registered')

d.save(sys.argv[2])
print('applied', len(d.log), 'patches')
for p, w in d.log: print(' -', p, '::', w)
