import asyncio, sys, json
from harness import *
async def main(html, shot):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html, viewport=(640, 400))
            await go(page, "https://cesium.test/viewer.html", 500)
            for _ in range(80):
                st = await fr(page, "w.__cz && w.__cz.stage")
                if st in ("running", "failed"): break
                await page.wait_for_timeout(500)
            await page.wait_for_timeout(3000)
            print(json.dumps(await fr(page, "JSON.parse(JSON.stringify(w.__cz||{}))"), indent=1)[:1200])
            await page.screenshot(path=shot)
            noisy = ('quirky','font-','background-color','padding: 4','color: #')
            for l in [l for l in page.logs if l.startswith(('[error]','[pageerror]','[warning]')) and not any(n in l for n in noisy)][:14]: print(l[:420])
            await b.close()
    finally: srv.terminate()
asyncio.run(main(*sys.argv[1:3]))
