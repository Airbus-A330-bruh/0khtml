import asyncio, sys, json, subprocess, time, socket
from harness import *
def wisp():
    p = subprocess.Popen(["node", "wisp_server.js"], cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for _ in range(50):
        try: socket.create_connection(("127.0.0.1", 8100), 0.2).close(); return p
        except OSError: time.sleep(0.1)
    raise RuntimeError("wisp did not start")
async def main(html):
    srv, w = start_server(), wisp()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html)
            await page.evaluate(f"{VSW}.navigate({VSW}.topEl, 'http://127.0.0.1:8099/__h/game.test/lcurl.html')")
            for _ in range(80):
                try:
                    if await fr(page, "w.__L && w.__L.done"): break
                except Exception: pass
                await page.wait_for_timeout(500)
            print(json.dumps(await fr(page, "JSON.parse(JSON.stringify(w.__L||{}))"), indent=1))
            for l in page.logs:
                if any(k in l for k in ('quirky','font-','background-color','padding: 4','color: #')): continue
                print(l[:300])
            await b.close()
    finally:
        srv.terminate(); w.terminate()
if __name__ == '__main__':
    asyncio.run(main(sys.argv[1]))
