"""Run a real game build (served by the test server) inside the proxied page and report what happened.
usage: run_game.py <test_html> <url> <shot.png> [seconds] [--libcurl]"""
import asyncio, sys, json
from harness import *
from run_libcurl import wisp

async def main(html, url, shot, secs, use_wisp):
    srv = start_server(); w = wisp() if use_wisp else None
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=CHROME_ARGS)
            ctx = await b.new_context(viewport={"width": 1100, "height": 760})
            page = await ctx.new_page(); page.logs = []; page.dialogs = []
            page.on("console", lambda m: page.logs.append(f"[{m.type}] {m.text[:600]}"))
            page.on("pageerror", lambda e: page.logs.append(f"[pageerror] {str(e)[:600]}"))
            async def on_dialog(d): page.dialogs.append(d.message[:800]); await d.dismiss()
            page.on("dialog", lambda d: asyncio.ensure_future(on_dialog(d)))
            await page.goto("file://" + html)
            await page.wait_for_function(f"!!({VSW} && {VSW}.topEl)", timeout=30000)
            await page.wait_for_timeout(1000)
            await page.evaluate(f"{VSW}.navigate({VSW}.topEl, {json.dumps(url)})")
            stable_since = 0
            for i in range(int(secs) * 2):
                await page.wait_for_timeout(500)
                if page.dialogs: break
                if i > 20 and i % 4 == 0:
                    try:
                        ok = await fr(page, "(()=>{const c=w.document.querySelector('canvas'); return !!(c&&c.width>100)})()")
                    except Exception: ok = False
                    if ok and not stable_since: stable_since = i
                    if stable_since and i - stable_since > 24: break
            st = await fr(page, """(()=>{const d=w.document; const c=d.querySelector('canvas'); const lc=d.querySelector('#unity-loading-container,#status,#loading'); return {title:d.title, canvas:!!c, canvasSize:c?[c.width,c.height]:null, loadingDisplay:lc?getComputedStyle(lc).display:null, bodyText:(d.body.innerText||'').slice(0,200)}})()""")
            # is anything actually drawn / animating?
            draw = await fr(page, """(()=>{const c=w.document.querySelector('canvas'); if(!c) return null; try{const t=w.document.createElement('canvas');t.width=c.width;t.height=c.height;const x=t.getContext('2d');x.drawImage(c,0,0);const d=x.getImageData(0,0,t.width,t.height).data;const seen=new Set();for(let i=0;i<d.length;i+=4*211)seen.add((d[i]>>4)+','+(d[i+1]>>4)+','+(d[i+2]>>4));return {distinctColours:seen.size}}catch(e){return {err:String(e)}}})()""")
            print("STATE:", json.dumps(st)); print("PIXELS:", json.dumps(draw)); print("ALERTS:", page.dialogs)
            await page.screenshot(path=shot)
            noisy = ('quirky','font-','background-color','padding: 4','color: #')
            print("---- console (errors/warnings first)")
            for l in [l for l in page.logs if l.startswith(('[error]','[pageerror]','[warning]')) and not any(n in l for n in noisy)][:25]: print(l[:500])
            await b.close()
    finally:
        srv.terminate()
        if w: w.terminate()
a = sys.argv
asyncio.run(main(a[1], a[2], a[3], a[4] if len(a) > 4 and not a[4].startswith('--') else 60, '--libcurl' in a))
