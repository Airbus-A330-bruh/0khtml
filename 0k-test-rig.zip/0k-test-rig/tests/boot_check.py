import asyncio, sys
from playwright.async_api import async_playwright
async def run(path):
    async with async_playwright() as p:
        b = await p.chromium.launch(args=["--no-sandbox"])
        page = await (await b.new_context(viewport={"width":1280,"height":800})).new_page()
        logs=[]
        page.on("console", lambda m: logs.append(f"[{m.type}] {m.text[:200]}"))
        page.on("pageerror", lambda e: logs.append(f"[pageerror] {str(e)[:300]}"))
        await page.goto("file://"+path); await page.wait_for_timeout(7000)
        info = await page.evaluate("({title:document.title, fileMode:globalThis.__zkFileMode, frames:document.querySelectorAll('iframe').length, vsw:!!globalThis[Symbol.for('zk.vsw')]})")
        await b.close(); return info, logs
async def main():
    for name,path in (("ORIGINAL v4","/home/claude/work/index.v4.html"),("PATCHED   ","/home/claude/work/index.fixed.html")):
        info,logs = await run(path)
        errs=[l for l in logs if l.startswith('[pageerror]') or l.startswith('[error]')]
        print(name, info, "| errors:", len(errs))
        for l in errs[:5]: print("    ",l)
asyncio.run(main())
