import asyncio, sys, json
from harness import *
from run_libcurl import wisp
async def main(html):
    srv, w = start_server(), wisp()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html)
            await page.evaluate(f"{VSW}.navigate({VSW}.topEl, 'http://127.0.0.1:8099/__h/game.test/spa2.html')")
            for _ in range(240):
                try:
                    if await fr(page, "w.__s2 && w.__s2.stage==='done'"): break
                except Exception: pass
                await page.wait_for_timeout(500)
            print(json.dumps(await fr(page, "JSON.parse(JSON.stringify(w.__s2||{}))")))
            await b.close()
    finally: srv.terminate(); w.terminate()
asyncio.run(main(sys.argv[1]))
