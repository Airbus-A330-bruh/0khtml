import asyncio, sys, json, subprocess, os, time, socket
from playwright.async_api import async_playwright
from harness import CHROME_ARGS, HERE
async def main():
    env = dict(os.environ, DIRECT_HOST="cesium.test")
    srv = subprocess.Popen(["node","server.js"], cwd=HERE, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for _ in range(50):
        try: socket.create_connection(("127.0.0.1",8099),0.2).close(); break
        except OSError: time.sleep(0.1)
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=CHROME_ARGS)
            page = await (await b.new_context(viewport={"width":640,"height":400})).new_page()
            logs=[]; page.on("console", lambda m: logs.append(f"[{m.type}] {m.text[:300]}")); page.on("pageerror", lambda e: logs.append("[pageerror] "+str(e)[:300]))
            await page.goto("http://127.0.0.1:8099/viewer.html")
            await page.wait_for_function("window.__cz && (window.__cz.stage==='running'||window.__cz.stage==='failed')", timeout=60000)
            await page.wait_for_timeout(3000)
            print(json.dumps(await page.evaluate("JSON.parse(JSON.stringify(window.__cz))")))
            await page.screenshot(path="cesium_control.png")
            for l in [l for l in logs if l.startswith(('[error]','[pageerror]'))][:6]: print(l)
            await b.close()
    finally: srv.terminate()
asyncio.run(main())
