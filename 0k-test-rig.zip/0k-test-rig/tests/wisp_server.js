const http = require('http');
const wisp = require('wisp-server-node');
const s = http.createServer((q, r) => { r.writeHead(200); r.end('wisp'); });
s.on('upgrade', (req, socket, head) => { try { wisp.routeRequest(req, socket, head); } catch (e) { console.error('wisp err', e); socket.destroy(); } });
process.on('uncaughtException', (e) => console.error('UNCAUGHT', e && e.message));
s.listen(8100, '127.0.0.1', () => console.log('wisp on 8100'));
