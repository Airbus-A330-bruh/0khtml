import asyncio, sys, json
from harness import *

async def main(html, out):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html)
            await page.evaluate("globalThis.__zkRetryCfg={ttfb:1200,tries:3,backoff:30,resTimeout:20000}")
            await go(page, "https://game.test/features.html", 500)
            try:
                await page.wait_for_function(f"{VSW}.topEl.contentWindow.__DONE === true", timeout=180000)
            except Exception as e:
                print("TIMEOUT waiting for __DONE:", e)
            res = await fr(page, "w.__RESULTS || {}")
            json.dump(res, open(out, "w"), indent=1)
            fails = {k: v for k, v in res.items() if not v.get("ok")}
            print(f"{len(res)-len(fails)}/{len(res)} passed, {len(fails)} failed\n")
            print("---- FAILURES")
            for k, v in fails.items(): print(f"FAIL {k}: {v.get('detail')}")
            print("\n---- INFO")
            for k, v in res.items():
                if v.get("ok") and v.get("detail"): print(f"info {k}: {v['detail']}")
            print("\n---- console (non-trivial)")
            for l in page.logs[-40:]: print(l)
            await b.close()
    finally:
        srv.terminate()

asyncio.run(main(sys.argv[1], sys.argv[2]))
