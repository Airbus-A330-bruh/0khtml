import asyncio, sys, json
from harness import *
async def main(html, shot):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html, viewport=(640, 400))
            await go(page, "https://cesium.test/flight.html", 500)
            for _ in range(160):
                st = await fr(page, "w.__fl && w.__fl.stage")
                if st in ("done", "failed"): break
                await page.wait_for_timeout(500)
            r = await fr(page, "JSON.parse(JSON.stringify(w.__fl||{}))")
            tiles = await page.evaluate("fetch('http://127.0.0.1:8099/__h/cesium.test/tiles-counter').then(r=>r.json())")
            print(json.dumps({k: r.get(k) for k in ('stage','frames','tilesLoaded','flightSteps','errors')}), "| tile requests served:", tiles, "| scheduler:", r.get('sched'))
            await page.screenshot(path=shot); await b.close()
    finally: srv.terminate()
asyncio.run(main(*sys.argv[1:3]))
