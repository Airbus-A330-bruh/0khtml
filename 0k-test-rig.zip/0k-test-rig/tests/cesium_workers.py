import asyncio, sys, json
from harness import *
async def main(html):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=CHROME_ARGS)
            ctx = await b.new_context(viewport={"width":640,"height":400}); page = await ctx.new_page()
            workers=[]; wlogs=[]
            def on_worker(w):
                workers.append(w); w.on("console", lambda m: wlogs.append(f"[worker {m.type}] {m.text[:300]}"))
            page.on("worker", on_worker)
            page.on("console", lambda m: wlogs.append(f"[page {m.type}] {m.text[:300]}") if m.type in ('error','warning') and 'quirky' not in m.text and 'font' not in m.text else None)
            page.on("pageerror", lambda e: wlogs.append("[pageerror] "+str(e)[:300]))
            await page.goto("file://"+html)
            await page.wait_for_function(f"!!({VSW} && {VSW}.topEl)", timeout=30000)
            await go(page, "https://cesium.test/viewer.html", 500)
            await page.wait_for_timeout(15000)
            print("workers created:", len(workers))
            for idx in (0,1,2):
                if idx >= len(workers): continue
                try:
                    res = await workers[idx].evaluate("""async () => {
                      const out = {onmessageType: typeof self.onmessage, posted: []};
                      const op = self.postMessage;
                      self.postMessage = function (m, t) { try { out.posted.push({keys: Object.keys(m||{}), type: m && m.$scramjet$messagetype, hasTransfer: !!t}); } catch (e) {} return op.apply(self, arguments); };
                      try {
                        const r = self.onmessage({ data: { id: 777, parameters: { array: new Int8Array(1) }, canTransferArrayBuffer: true } });
                        out.returned = r && typeof r.then === 'function' ? 'promise' : typeof r;
                        await new Promise(res => setTimeout(res, 500));
                      } catch (e) { out.threw = String(e && e.stack || e).slice(0, 300); }
                      return out; }""")
                except Exception as e: res = "eval failed: "+str(e)[:160]
                print(" worker", idx, json.dumps(res)[:500])
            for l in wlogs[:15]: print(l)
            await b.close()
    finally: srv.terminate()
asyncio.run(main(sys.argv[1]))
