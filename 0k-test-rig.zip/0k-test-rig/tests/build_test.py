"""Create test.html from a given 0K file:// build: swaps the WebRTC tunnel for the local test server.
Only a COPY is patched; the shipped file is never touched by this script."""
import sys, re
src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf8').read()

PREAMBLE = r'''<script id="zk-test">
globalThis.__zkTest = (() => {
  const HTTP = 'http://127.0.0.1:8099/__h/', WS = 'ws://127.0.0.1:8099/__h/';
  const FORBID = /^(cookie2?|referer|origin|host|user-agent|accept-encoding|accept-charset|connection|content-length|date|dnt|expect|keep-alive|te|trailer|transfer-encoding|upgrade|via|sec-.*|proxy-.*|access-control-request-.*)$/i;
  const log = (globalThis.__zkTestLog = []);
  async function request(remote, method, body, headers, signal) {
    const u = new URL(remote.href);
    const fid = u.searchParams.get('__id');
    if (fid) {   // failure injection: ?__id=X&__flaky=N (first N attempts fail like libcurl), &__hang=M (next M attempts never answer)
      const cnt = (globalThis.__zkTestCount = globalThis.__zkTestCount || {});
      const n = (cnt[fid] = (cnt[fid] || 0) + 1);
      const fl = +u.searchParams.get('__flaky') || 0, hg = +u.searchParams.get('__hang') || 0;
      if (n <= fl) throw new Error('Request "' + remote.href + '" failed with error code 92: Stream error in the HTTP/2 framing layer');
      if (n <= fl + hg) return new Promise((_, rej) => { if (signal) signal.addEventListener('abort', () => rej(new DOMException('aborted', 'AbortError')), { once: true }); });
    }
    const init = { method, redirect: 'manual', signal, headers: new Headers() };
    for (const [k, v] of headers) { try { init.headers.append(FORBID.test(k) ? 'x-zk-h-' + k : k, v); } catch {} }
    if (body && method !== 'GET' && method !== 'HEAD') init.body = await new Response(body).arrayBuffer();
    log.push(method + ' ' + remote.href);
    const r = await fetch(HTTP + u.host + u.pathname + u.search, init);
    let status = r.status;
    const hdrs = [...r.headers].filter(([k]) => !k.startsWith('access-control-') && !k.startsWith('x-zk-'));
    const rs = r.headers.get('x-zk-real-status'); if (rs) status = +rs;
    const sc = r.headers.get('x-zk-set-cookie'); if (sc) for (const c of JSON.parse(sc)) hdrs.push(['set-cookie', c]);
    return { status, statusText: r.statusText || '', headers: hdrs, body: r.body ?? new ArrayBuffer(0) };
  }
  // mirrors the patched ul(): reports the protocol the server selected
  function connect(url, protocols, headers, onopen, onmessage, onclose, onerror) {
    const u = new URL(url.toString());
    log.push('WS ' + u.href);
    const hq = (u.search ? '&' : '?') + '__zkh=' + encodeURIComponent(JSON.stringify(headers || []));
    const ws = new WebSocket(WS + u.host + u.pathname + u.search + hq, protocols);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => onopen(ws.protocol || '', '');
    ws.onclose = (e) => onclose(e.code, e.reason);
    ws.onerror = () => onerror('test transport ws error');
    ws.onmessage = (e) => onmessage(e.data);
    return [(d) => { if (ws.readyState !== 1) throw Error('not open'); if (d instanceof Blob) d.arrayBuffer().then((b) => ws.send(b)); else ws.send(d); }, (c, r) => ws.close(c, r)];
  }
  return { request, connect };
})();
</script>
'''

def sub1(pat, rep, s):
    n = s.count(pat)
    assert n == 1, f'pattern matched {n}x: {pat}'
    return s.replace(pat, rep)

s = sub1('async function ll(e,t,n,r,i){', 'async function ll(e,t,n,r,i){return globalThis.__zkTest.request(e,t,n,r,i);', s)
s = sub1('function ul(e,t,n,r,i,a,o){', 'function ul(e,t,n,r,i,a,o){return globalThis.__zkTest.connect(e,t,n,r,i,a,o);', s)
s = sub1('async function il(e){', 'async function il(e){return;', s)
# put the preamble right after the very first <script> block
i = s.index('</script>') + len('</script>')
s = s[:i] + '\n' + PREAMBLE + s[i:]
open(dst, 'w', encoding='utf8').write(s)
print('built', dst, len(s))
