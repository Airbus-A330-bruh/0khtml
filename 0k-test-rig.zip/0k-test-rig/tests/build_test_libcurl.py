"""Test build that keeps the REAL libcurl.js (wasm, HTTPSession, WebSocket class, patched ul()) and only replaces the
bottom transport (WebRTC 'pulsar' tunnel) with a local Wisp relay."""
import sys
src, dst = sys.argv[1], sys.argv[2]
s = open(src, encoding='utf8').read()
def sub1(pat, rep):
    global s
    assert s.count(pat) == 1, (s.count(pat), pat[:80])
    s = s.replace(pat, rep)
# tunnel always "connected"
sub1('function tl(){return Z.connection?.pc.connectionState===`connected`&&Z.connection?.keepalive.readyState===`open`}', 'function tl(){return true}')
# configure libcurl to talk wisp to the local relay instead of the WebRTC transport
sub1('function sl(){if(Z.transportConfigured)return;if(!Z.connection)throw Error(`Tunnel is not connected`);let e=Gc(Z.connection.pc);Kc.transport=function(t){return e(t)},Kc.set_websocket(`wss://pulsar-tunnel.local/`),Z.transportConfigured=!0}',
     'function sl(){if(Z.transportConfigured)return;Kc.transport=`wisp`;Kc.set_websocket(`ws://127.0.0.1:8100/`);Z.transportConfigured=!0}')
# il(): no tunnel to connect
sub1('async function il(e){', 'async function il(e){return;')
open(dst, 'w', encoding='utf8').write(s)
print('built', dst)
