import asyncio, sys, json
from harness import *
# usage: probe.py <html> <url> <js-in-frame (async fn body)> [wait_ms]
async def main(html, url, code, wait=2500):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html)
            await go(page, url, 800)
            r = await page.evaluate(f"""(async()=>{{const w={VSW}.topEl.contentWindow; const R=await (async()=>{{{code}}})().catch(e=>'THROW '+(e&&e.stack||e)); return R;}})()""")
            print("RESULT:", json.dumps(r, indent=1) if not isinstance(r,str) else r)
            await page.wait_for_timeout(int(wait))
            print("---- console")
            for l in page.logs:
                if 'Failed to load resource' in l and 'REFUSED' not in l: continue
                print(l[:1800])
            await b.close()
    finally:
        srv.terminate()
asyncio.run(main(*sys.argv[1:]))
