// Local stand-in for "the internet" behind the 0K tunnel.
// Requests arrive as /__h/<host>/<path>; static sites live in sites/<host>/.
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { WebSocketServer } = require('ws');
const { Server: IOServer } = require('socket.io');

const PORT = +process.env.PORT || 8099;
const ROOT = path.join(__dirname, 'sites');
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.wav': 'audio/wav', '.wasm': 'application/wasm',
  '.json': 'application/json', '.woff2': 'font/woff2', '.bin': 'application/octet-stream', '.glb': 'model/gltf-binary',
};
const FORBIDDEN_PREFIX = 'x-zk-h-';
const stats = { wsConnections: 0, wsMessages: 0 };
const tileCache = {};
function makeTilePng(k) {   // 256x256 solid colour + 1px border, written with zlib (no image library)
  const w = 256, h = 256, raw = Buffer.alloc((w * 3 + 1) * h);
  const col = [[60 + k * 12, 120, 200 - k * 8], 1][0];
  for (let y = 0; y < h; y++) { raw[y * (w * 3 + 1)] = 0; for (let x = 0; x < w; x++) { const o = y * (w * 3 + 1) + 1 + x * 3; const edge = x === 0 || y === 0; raw[o] = edge ? 255 : col[0]; raw[o + 1] = edge ? 255 : col[1]; raw[o + 2] = edge ? 255 : col[2]; } }
  const crcT = []; for (let n = 0; n < 256; n++) { let c = n; for (let i = 0; i < 8; i++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crcT[n] = c >>> 0; }
  const crc = (b) => { let c = 0xffffffff; for (const v of b) c = crcT[(c ^ v) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (t, d) => { const l = Buffer.alloc(4); l.writeUInt32BE(d.length); const td = Buffer.concat([Buffer.from(t), d]); const c = Buffer.alloc(4); c.writeUInt32BE(crc(td)); return Buffer.concat([l, td, c]); };
  const ihdr = Buffer.alloc(13); ihdr.writeUInt32BE(w, 0); ihdr.writeUInt32BE(h, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk('IHDR', ihdr), chunk('IDAT', zlib.deflateSync(raw)), chunk('IEND', Buffer.alloc(0))]);
}


function reply(res, status, headers, body) {
  // fetch() hides 3xx + Set-Cookie from the page, so ship the "real" values in side-channel headers.
  const h = { ...headers };
  const cookies = h['set-cookie'];
  delete h['set-cookie'];
  if (cookies) h['x-zk-set-cookie'] = JSON.stringify([].concat(cookies));
  if (status >= 300 && status < 400) {
    h['x-zk-real-status'] = String(status);
    status = 200;
  }
  h['access-control-allow-origin'] = '*';
  h['access-control-allow-headers'] = '*';
  h['access-control-allow-methods'] = '*';
  h['access-control-expose-headers'] = '*';
  h['access-control-max-age'] = '600';
  h['cache-control'] = h['cache-control'] || 'no-store';
  if (process.env.NOKEEPALIVE) h['connection'] = 'close';
  res.writeHead(status, h);
  res.end(body);
}

// engine.io (socket.io) – manual attach so our header fix-ups run first
const { Server: EngineServer } = require('engine.io');
const engine = new EngineServer({ path: '/__h/mp.test/socket.io/', cors: { origin: '*' } });
const io = new IOServer({ serveClient: false });
io.bind(engine);
process.on('uncaughtException', (e) => console.error('UNCAUGHT', e && e.stack || e));
process.on('unhandledRejection', (e) => console.error('UNHANDLED', e && e.stack || e));
io.on('connection', (s) => {
  s.emit('hello', { id: s.id, transport: s.conn.transport.name });
  s.on('ping-ack', (data, cb) => cb && cb({ echo: data, transport: s.conn.transport.name }));
  s.on('move', (d) => s.broadcast.emit('move', { id: s.id, ...d }));
  s.on('bin', (buf, cb) => cb && cb(Buffer.from(buf).length));
});

const wss = new WebSocketServer({ noServer: true, handleProtocols: (p) => (p.has('game.v1') ? 'game.v1' : false) });
wss.on('headers', (h, req) => { stats.lastHandshake = { reqProtocol: req.headers['sec-websocket-protocol'] || null, reqCookie: req.headers.cookie || null, reqOrigin: req.headers.origin || null, respHeaders: h.filter((x) => /protocol/i.test(x)) }; });
const rooms = new Map();
wss.on('connection', (ws, req) => {
  stats.wsConnections++;
  const host = req.zkHost;
  const room = rooms.get(host) || rooms.set(host, new Set()).get(host);
  room.add(ws);
  ws.id = Math.random().toString(36).slice(2, 8);
  let hk = ''; try { const q = new URL(req.url, 'http://x').searchParams.get('__zkh'); if (q) for (const [k, v] of JSON.parse(q)) if (String(k).toLowerCase() === 'cookie') hk = v; } catch {}
  ws.send(JSON.stringify({ type: 'welcome', id: ws.id, players: room.size, proto: ws.protocol, cookie: hk }));
  ws.on('message', (data, isBinary) => {
    stats.wsMessages++;
    if (!isBinary) {
      const t = data.toString();
      if (t.startsWith('close:')) return ws.close(+t.slice(6) || 4001, 'bye');
      if (t.startsWith('burst:')) {   // server pushes N small binary frames back-to-back (game state stream)
        const n = +t.slice(6) || 100;
        for (let i = 0; i < n; i++) { const b = Buffer.alloc(32); b.writeUInt32LE(i, 0); ws.send(b, { binary: true }); }
        ws.send('burst-done');
        return;
      }
      if (t === 'broadcast') {
        for (const o of room) if (o !== ws && o.readyState === 1) o.send(JSON.stringify({ type: 'peer', from: ws.id }));
        return;
      }
    }
    ws.send(data, { binary: isBinary }); // echo
  });
  ws.on('close', () => room.delete(ws));
});

function parseReq(req) {
  const u = new URL(req.url, 'http://x');
  const m = u.pathname.match(/^\/__h\/([^/]+)(\/.*)?$/);
  if (!m && process.env.DIRECT_HOST) return { host: process.env.DIRECT_HOST, pathname: u.pathname, search: u.search, q: u.searchParams };   // control runs: no proxy
  if (!m) return null;
  // restore headers the browser would not let us set
  for (const k of Object.keys(req.headers)) if (k.startsWith(FORBIDDEN_PREFIX)) req.headers[k.slice(FORBIDDEN_PREFIX.length)] = req.headers[k];
  return { host: m[1], pathname: m[2] || '/', search: u.search, q: u.searchParams };
}

function readBody(req) {
  return new Promise((r) => {
    const c = [];
    req.on('data', (d) => c.push(d));
    req.on('end', () => r(Buffer.concat(c)));
  });
}

const server = http.createServer(async (req, res) => {
  const p = parseReq(req);
  if (!p) return reply(res, 404, {}, 'not a proxied url');
  if (req.method === 'OPTIONS') return reply(res, 204, {}, '');
  req.zkHost = p.host;
  if (p.pathname.startsWith('/socket.io/') && p.host === 'mp.test') {
    req.url = '/__h/mp.test' + p.pathname + p.search;
    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-expose-headers', '*');
    return engine.handleRequest(req, res);
  }
  const body = await readBody(req);
  try {
    switch (p.pathname) {
      case '/api/echo':
        return reply(res, 200, { 'content-type': 'application/json', 'x-custom': 'yes' }, JSON.stringify({
          method: req.method, host: p.host, url: p.pathname + p.search, cookie: req.headers.cookie || '',
          referer: req.headers.referer || '', origin: req.headers.origin || '', ct: req.headers['content-type'] || '',
          ua: req.headers['user-agent'] || '', body: body.toString('base64'), bodyText: body.toString('utf8'),
          xtest: req.headers['x-test'] || '', accept: req.headers.accept || '',
        }));
      case '/redirect': {
        const to = p.q.get('to') || '/api/echo';
        return reply(res, +p.q.get('code') || 302, { location: to }, '');
      }
      case '/cookie/set':
        return reply(res, 200, { 'set-cookie': [`srv=${p.q.get('v') || '1'}; Path=/`, 'srv2=x; Path=/; Max-Age=3600'], 'content-type': 'text/plain' }, 'ok');
      case '/slow':
        await new Promise((r) => setTimeout(r, +p.q.get('ms') || 200));
        return reply(res, 200, { 'content-type': 'text/plain' }, 'slow-ok');
      case '/big.bin': {
        const n = +p.q.get('size') || 1 << 20;
        const b = Buffer.alloc(n);
        for (let i = 0; i < n; i++) b[i] = i & 255;
        return reply(res, 200, { 'content-type': 'application/octet-stream' }, b);
      }
      case '/status':
        return reply(res, +p.q.get('code') || 200, { 'content-type': 'text/plain' }, 'status ' + p.q.get('code'));
      case '/stream': {
        res.writeHead(200, { 'content-type': 'text/plain', 'access-control-allow-origin': '*', 'access-control-expose-headers': '*' });
        let i = 0;
        const t = setInterval(() => {
          res.write('chunk' + i + '\n');
          if (++i >= 4) { clearInterval(t); res.end(); }
        }, 60);
        return;
      }
      case '/sse': {
        res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache', 'access-control-allow-origin': '*', 'access-control-expose-headers': '*' });
        let i = 0;
        res.write('retry: 100\n\n');
        const t = setInterval(() => {
          res.write(`data: tick${i}\n\n`);
          if (++i >= 3) { clearInterval(t); }
        }, 80);
        req.on('close', () => clearInterval(t));
        return;
      }
      case '/gz': {
        const gz = zlib.gzipSync(Buffer.from('compressed-ok'));
        return reply(res, 200, { 'content-type': 'text/plain', 'content-encoding': 'gzip' }, gz);
      }
      case '/tiles-counter':
        return reply(res, 200, { 'content-type': 'application/json' }, JSON.stringify(stats.tiles || 0));
      case '/stats':
        return reply(res, 200, { 'content-type': 'application/json' }, JSON.stringify(stats));
      case '/nocontenttype':
        return reply(res, 200, {}, '<h1>no ct</h1>');
      case '/csp.html':
        return reply(res, 200, { 'content-type': 'text/html', 'content-security-policy': "default-src 'none'; script-src 'self'", 'x-frame-options': 'DENY' }, '<!doctype html><title>csp</title><script>document.title="csp-ran"</script><p>csp page</p>');
    }
    const tm = p.pathname.match(/^\/tiles\/(\d+)\/(\d+)\/(\d+)\.png$/);
    if (tm) {
      stats.tiles = (stats.tiles || 0) + 1;
      const [z, x, y] = [+tm[1], +tm[2], +tm[3]];
      await new Promise((r) => setTimeout(r, 15 + ((x * 7 + y * 13) % 30)));   // a little latency, like a real tile server
      const key = `${(x * 37 + y * 17 + z * 91) % 16}`;
      tileCache[key] = tileCache[key] || makeTilePng((x * 37 + y * 17 + z * 91) % 16);
      return reply(res, 200, { 'content-type': 'image/png' }, tileCache[key]);
    }
    // static
    let rel = decodeURIComponent(p.pathname);
    if (rel.endsWith('/')) rel += 'index.html';
    let file = path.join(ROOT, p.host, rel);
    if (!file.startsWith(ROOT)) return reply(res, 403, {}, 'no');
    if (rel.startsWith('/three/')) file = path.join(__dirname, 'node_modules/three', rel.slice(7));
    if (rel.startsWith('/cesium/')) file = path.join(__dirname, 'node_modules/cesium/Build/Cesium', rel.slice(8));
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) return reply(res, 404, { 'content-type': 'text/plain' }, 'not found: ' + p.host + rel);
    let ext = path.extname(file);
    const hdr = {};
    if (ext === '.br' || ext === '.gz') {   // behave like Netlify/Nginx for precompressed Unity/Godot builds
      hdr['content-encoding'] = ext === '.br' ? 'br' : 'gzip';
      ext = path.extname(file.slice(0, -ext.length));
      if (ext === '.unityweb') ext = '.bin';
    }
    hdr['content-type'] = MIME[ext] || 'application/octet-stream';
    let data = fs.readFileSync(file);
    if (process.env.GZIPALL && !hdr['content-encoding'] && ['.wasm', '.js', '.pck', '.html', '.bin'].includes(ext)) {   // like GitHub Pages
      data = zlib.gzipSync(data, { level: 1 });
      hdr['content-encoding'] = 'gzip';
      hdr['content-length'] = String(data.length);
    }
    return reply(res, 200, hdr, data);
  } catch (e) {
    return reply(res, 500, { 'content-type': 'text/plain' }, String(e && e.stack || e));
  }
});

server.on('upgrade', (req, socket, head) => {
  if (String(req.headers.upgrade || '').toLowerCase() !== 'websocket') {
    // e.g. curl's "Upgrade: h2c" on plain http: servers just ignore it and answer normally
    delete req.headers.upgrade;
    const res = new http.ServerResponse(req);
    res.assignSocket(socket);
    res.on('finish', () => res.detachSocket(socket));
    return server.emit('request', req, res);
  }
  const p = parseReq(req);
  if (!p) return socket.destroy();
  req.zkHost = p.host;
  if (p.pathname.startsWith('/socket.io/') && p.host === 'mp.test') {
    req.url = '/__h/mp.test' + p.pathname + p.search;
    return engine.handleUpgrade(req, socket, head);
  }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

server.listen(PORT, '127.0.0.1', () => console.log('test server on', PORT));
