import asyncio, sys, json
from harness import *
async def main(html, shot):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b, ctx, page = await boot(p, html)
            await go(page, "https://three.test/game.html", 500)
            for _ in range(60):
                st = await fr(page, "w.__game && w.__game.stage")
                if st in ("running", "failed"): break
                await page.wait_for_timeout(500)
            await page.wait_for_timeout(2500)
            g = await fr(page, "JSON.parse(JSON.stringify(w.__game||{}))")
            print(json.dumps(g, indent=1)[:1500])
            # sample the canvas: is it just the clear colour, or is the cube actually drawn?
            px = await fr(page, """(()=>{const c=w.document.getElementById('c'); if(!c) return null; const t=w.document.createElement('canvas'); t.width=640;t.height=400; const x=t.getContext('2d'); x.drawImage(c,0,0); const d=x.getImageData(0,0,640,400).data; const bg=[0x20,0x30,0x40]; let diff=0; const seen=new Set(); for(let i=0;i<d.length;i+=4*97){ if(Math.abs(d[i]-bg[0])+Math.abs(d[i+1]-bg[1])+Math.abs(d[i+2]-bg[2])>30) diff++; seen.add((d[i]>>4)+','+(d[i+1]>>4)+','+(d[i+2]>>4)); } return {nonBackgroundSamples:diff, distinctColours:seen.size}})()""")
            print("canvas:", px)
            await page.screenshot(path=shot)
            for l in page.logs[-12:]:
                if 'quirky' in l or 'font' in l or 'background-color' in l or 'padding' in l or 'color: #' in l: continue
                print(l[:500])
            await b.close()
    finally:
        srv.terminate()
asyncio.run(main(sys.argv[1], sys.argv[2]))
