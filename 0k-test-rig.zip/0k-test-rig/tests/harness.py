import asyncio, subprocess, sys, json, time, socket, os
from playwright.async_api import async_playwright

HERE = os.path.dirname(os.path.abspath(__file__))
CHROME_ARGS = ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist",
               "--autoplay-policy=no-user-gesture-required", "--enable-webgl"]

def start_server():
    p = subprocess.Popen(["node", "server.js"], cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for _ in range(50):
        try:
            socket.create_connection(("127.0.0.1", 8099), 0.2).close(); return p
        except OSError: time.sleep(0.1)
    raise RuntimeError("server did not start")

VSW = "globalThis[Symbol.for('zk.vsw')]"

async def boot(p, html, viewport=(1280, 800)):
    b = await p.chromium.launch(args=CHROME_ARGS)
    ctx = await b.new_context(viewport={"width": viewport[0], "height": viewport[1]})
    page = await ctx.new_page()
    page.logs = []
    page.on("console", lambda m: page.logs.append(f"[{m.type}] {m.text[:4000]}"))
    page.on("pageerror", lambda e: page.logs.append(f"[pageerror] {str(e)[:600]} || STACK: {(getattr(e,'stack','') or '')[:1800]}"))
    await page.goto("file://" + html)
    await page.wait_for_function(f"!!({VSW} && {VSW}.topEl)", timeout=30000)
    await page.wait_for_timeout(1500)
    return b, ctx, page

async def go(page, url, wait=1500):
    await page.evaluate(f"{VSW}.navigate({VSW}.topEl, {json.dumps(url)})")
    await page.wait_for_timeout(wait)

async def fr(page, expr):
    """evaluate an expression inside the proxied top window"""
    return await page.evaluate(f"(()=>{{const w={VSW}.topEl.contentWindow; return ({expr});}})()")
