"""Boot a real game build, perform input, and report whether the frame content changed.
usage: interact.py <test_html> <url> <wait_s> "<action;action;...>"   action = click:x,y | key:Name | wait:ms"""
import asyncio, sys, json, hashlib
from harness import *
async def main(html, url, wait_s, actions):
    srv = start_server()
    try:
        async with async_playwright() as p:
            b = await p.chromium.launch(args=CHROME_ARGS)
            page = await (await b.new_context(viewport={"width": 1100, "height": 760})).new_page()
            logs = []
            page.on("pageerror", lambda e: logs.append("pageerror: " + str(e)[:200]))
            page.on("dialog", lambda d: asyncio.ensure_future(d.dismiss()))
            await page.goto("file://" + html)
            await page.wait_for_function(f"!!({VSW} && {VSW}.topEl)", timeout=30000)
            await page.evaluate(f"{VSW}.navigate({VSW}.topEl, {json.dumps(url)})")
            await page.wait_for_timeout(int(wait_s) * 1000)
            async def snap(n):
                png = await page.screenshot(path=f"inter_{n}.png"); return hashlib.md5(png).hexdigest()[:8]
            prev = await snap(0); print("start frame", prev)
            for i, a in enumerate(actions.split(";"), 1):
                k, _, v = a.partition(":")
                if k == "click": x, y = map(int, v.split(",")); await page.mouse.move(x, y); await page.mouse.down(); await page.wait_for_timeout(80); await page.mouse.up()
                elif k == "key": await page.keyboard.press(v)
                elif k == "wait": await page.wait_for_timeout(int(v)); continue
                await page.wait_for_timeout(1800)
                h = await snap(i); print(f"after {a:<18} frame {h}  {'CHANGED' if h != prev else 'unchanged'}"); prev = h
            print("errors:", logs or "none")
            await b.close()
    finally: srv.terminate()
asyncio.run(main(*sys.argv[1:5]))
