import { answer } from './mod.js';
import hello from './mod.js';
self.postMessage({ boot: 'ready', hello: hello() });
self.onmessage = async (e) => {
  if (e.data === 'fetch') { const r = await fetch('/api/echo?from=module-worker'); postMessage({ fetched: (await r.json()).url }); }
  else if (e.data === 'ws') { const w = new WebSocket('wss://game.test/ws'); w.onmessage = (m) => { postMessage({ ws: JSON.parse(m.data).type }); w.close(); }; }
  else postMessage({ mod: answer, got: e.data });
};
