import { answer, viaDep } from './mod.js';
window.__mainmjs = answer + ':' + viaDep;
