window.__pm = {};
const t = (n, f) => { try { window.__pm[n] = String(f()); } catch (e) { window.__pm[n] = 'THROW ' + e.message; } };
function b1() { return(window).postMessage(1, '*'); }
function b2() { return(self.x=window).postMessage(2, '*'); }
function b3(o) { return(o?o:window).postMessage(3, '*'); }
function b4() { return[window][0].postMessage(4, '*'); }
function b5() { return(0,window).postMessage(5, '*'); }
function b6() { return typeof(window).postMessage; }
function b7() { throw(window).postMessage(7,'*'); }
function b8() { return void(window).postMessage(8,'*'); }
async function b9() { return await(window).postMessage(9,'*'); }
t('b1', b1); t('b2', b2); t('b3', b3); t('b4', b4); t('b5', b5); t('b6', b6); t('b7', b7); t('b8', b8);
