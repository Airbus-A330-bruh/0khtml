import { store, bump } from './shared.js';
window.__spa = { stage: 'entry', metaUrl: import.meta.url };
bump();
try {
  window.__spa.assetUrl = new URL('./pic.png', import.meta.url).href;      // Vite: new URL('./asset', import.meta.url)
} catch (e) { window.__spa.assetUrlErr = String(e.message); }
const a = await import('./chunk-a.js');          // lazy chunk that statically imports ./shared.js too
const b = await import('./chunk-b.js');
window.__spa.chunkA = a.hello(); window.__spa.chunkB = b.hello();
window.__spa.sharedCount = store.n;              // entry bumped 1, chunk A bumped 1, chunk B bumped 1  => 3 if ONE shared instance
window.__spa.sameStore = (a.store === store) && (b.store === store);
window.__spa.chunkMetaUrl = a.metaUrl;
// Vite-style worker + wasm via import.meta.url
try { const w = new Worker(new URL('./vworker.js', import.meta.url), { type: 'module' }); window.__spa.worker = await new Promise((res, rej) => { w.onmessage = (e) => res(e.data); w.onerror = (e) => rej(new Error('worker error ' + e.message)); setTimeout(() => rej(new Error('worker timeout')), 6000); }); } catch (e) { window.__spa.workerErr = String(e.message); }
try { const r = await WebAssembly.instantiateStreaming(fetch(new URL('/add.wasm', import.meta.url))); window.__spa.wasm = r.instance.exports.add(20, 22); } catch (e) { window.__spa.wasmErr = String(e.message); }
window.__spa.stage = 'done';
document.getElementById('app').textContent = 'rendered';
