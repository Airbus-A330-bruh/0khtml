import { store } from './shared.js';
postMessage({ worker: 'ok', ownStore: store.n });   // a worker has its OWN module instance (n starts at 0)
