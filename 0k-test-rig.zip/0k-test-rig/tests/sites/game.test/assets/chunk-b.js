import { store, bump } from './shared.js';
import { hello as helloA } from './chunk-a.js';
bump();
export { store };
export const hello = () => 'B>' + helloA();
