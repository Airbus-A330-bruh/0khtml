import { store, bump } from './shared.js';
bump();
export { store };
export const metaUrl = import.meta.url;
export const hello = () => 'A:' + store.n;
