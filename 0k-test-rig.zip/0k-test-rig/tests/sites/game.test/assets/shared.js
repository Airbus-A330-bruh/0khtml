export const store = { n: 0, id: Math.random().toString(36).slice(2) };
export const bump = () => ++store.n;
