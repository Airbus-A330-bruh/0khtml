window.__local='local-ok:'+document.currentScript.src;
