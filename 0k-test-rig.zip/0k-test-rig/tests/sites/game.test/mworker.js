import { answer } from './mod.js';
self.onmessage = (e) => postMessage({ mod: answer, got: e.data });
