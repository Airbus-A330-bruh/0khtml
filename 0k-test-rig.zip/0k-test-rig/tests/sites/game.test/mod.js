export const answer = 42;
export default function hello() { return 'hello-mod'; }
import { dep } from './dep.js';
export const viaDep = dep + 1;
