window.__ext = 'ext-ok';
