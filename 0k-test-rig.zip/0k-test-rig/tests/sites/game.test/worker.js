importScripts('/imp.js');
onmessage = async (e) => {
  const d = e.data;
  if (d.cmd === 'ping') return postMessage({ pong: d.v, imp: self.__imp });
  if (d.cmd === 'fetch') {
    try { const r = await fetch('/api/echo?from=worker'); const j = await r.json(); postMessage({ fetched: j.url }); }
    catch (err) { postMessage({ fetchErr: String(err) }); }
  }
  if (d.cmd === 'ws') {
    try {
      const ws = new WebSocket(d.url);
      ws.onmessage = (m) => { try { const j = JSON.parse(m.data); if (j.type === 'welcome') ws.send('hi-from-worker'); } catch { postMessage({ wsEcho: m.data }); ws.close(); } };
      ws.onerror = () => postMessage({ wsErr: 'error' });
    } catch (err) { postMessage({ wsErr: String(err) }); }
  }
  if (d.cmd === 'loc') postMessage({ href: self.location.href, origin: self.location.origin });
  if (d.cmd === 'wasm') {
    try { const r = await WebAssembly.instantiateStreaming(fetch('/add.wasm')); postMessage({ wasm: r.instance.exports.add(2, 3) }); }
    catch (err) { postMessage({ wasmErr: String(err) }); }
  }
};
