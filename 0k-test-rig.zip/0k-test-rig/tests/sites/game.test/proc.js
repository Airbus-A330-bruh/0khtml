class Counter extends AudioWorkletProcessor {
  constructor() { super(); this.n = 0; }
  process(inputs, outputs) { this.n++; if (this.n === 5) this.port.postMessage({ blocks: this.n, sampleRate }); return true; }
}
registerProcessor('zk-counter', Counter);
